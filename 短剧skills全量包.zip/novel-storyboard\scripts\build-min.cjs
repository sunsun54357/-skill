const fs = require("fs");
const path = require("path");
const stripBom = (s) => s.replace(/^\uFEFF/, "");

// 用法：node build-min.cjs <剧名>-cast.json <剧名>-art.json <剧名>-分镜.json <剧名>-outline.json [--out <目录>]
// 产出 <剧名>-提示词清单.html：人物/场景/道具出图提示词 + 分镜视频提示词（总控台风格），全"名字+复制"，时长整秒。
function parseArgs(argv) {
  const a = { _: [] };
  for (let i = 0; i < argv.length; i++) {
    const x = argv[i];
    if (x.startsWith("--")) a[x.slice(2)] = argv[++i];
    else a._.push(x);
  }
  return a;
}
const a = parseArgs(process.argv.slice(2));
const [castPath, artPath, sbPath, outlinePath] = a._;
if (!castPath || !artPath || !sbPath || !outlinePath) {
  console.error("用法：node build-min.cjs <cast.json> <art.json> <分镜.json> <outline.json> [--out <目录>]");
  process.exit(1);
}
const src = path.basename(castPath).replace(/-cast\.json$/, "");
const outDir = a.out || path.dirname(path.resolve(castPath));
const cast = JSON.parse(stripBom(fs.readFileSync(castPath, "utf8")));
const art = JSON.parse(stripBom(fs.readFileSync(artPath, "utf8")));
const sb = JSON.parse(stripBom(fs.readFileSync(sbPath, "utf8")));
const outline = JSON.parse(stripBom(fs.readFileSync(outlinePath, "utf8")));

const esc = (s) => String(s ?? "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");

// ---- 完整提示词包组装：场景/人物/道具复制时给"最完整的一份" ----
function imgBlock(img, indent) {
  const out = [];
  if (!img) return out;
  if (img.prompt) out.push(`${indent}主图提示词：\n${img.prompt}`);
  if (img.sheet) out.push(`${indent}设定图版面（sheet）：\n${img.sheet}`);
  if (img.negativePrompt) out.push(`${indent}负面词（negative prompt）：\n${img.negativePrompt}`);
  if (Array.isArray(img.tags) && img.tags.length) out.push(`${indent}风格标签：${img.tags.join(", ")}`);
  return out;
}
function scenePack(s) {
  const parts = [];
  if (s.summary) parts.push(`【设计意图】\n${s.summary}`);
  if (Array.isArray(s.anchors) && s.anchors.length) {
    parts.push(`【一致性锚点】\n${s.anchors.map((x) => `- ${x.name}：${x.desc}`).join("\n")}`);
  }
  if (Array.isArray(s.lighting) && s.lighting.length) {
    parts.push(`【光照状态】\n${s.lighting.map((l) => `◆ ${l.state}\n${l.prompt}`).join("\n")}`);
  }
  parts.push(...imgBlock(s.image, "【图】"));
  if (s.variantOf) parts.push(`【变体】复用 ${s.variantOf}：${s.changes || ""}`);
  return parts.join("\n\n");
}
function propPack(p) {
  const parts = [];
  if (p.summary) parts.push(`【戏剧功能】\n${p.summary}`);
  if (Array.isArray(p.anchors) && p.anchors.length) {
    parts.push(`【细节锚点】\n${p.anchors.map((x) => `- ${x.name}：${x.desc}`).join("\n")}`);
  }
  if (Array.isArray(p.states) && p.states.length) {
    parts.push(`【状态变体】\n${p.states.map((l) => `◆ ${l.state}\n${l.prompt}`).join("\n")}`);
  }
  if (p.scale) parts.push(`【尺度】${p.scale}`);
  parts.push(...imgBlock(p.image, "【图】"));
  return parts.join("\n\n");
}
function charPack(c) {
  const parts = [];
  const o = c.persona || {};
  if (o.identity || o.appearance) {
    const bits = [];
    if (o.gender && o.ageRange) bits.push(`${o.gender}，${o.ageRange}`);
    if (o.identity) bits.push(`身份：${o.identity}`);
    if (o.appearance) bits.push(`外观：${o.appearance}`);
    parts.push(`【设定】${bits.join("；")}`);
  }
  if (c.oneLiner) parts.push(`【一句话】${c.oneLiner}`);
  parts.push(...imgBlock(c.image, "【图】"));
  return parts.join("\n\n");
}

const peopleRows = cast.characters
  .map((c) => ({ name: c.name, prompt: (c.image && (c.image.prompt || c.image.sheet)) ? charPack(c) : "" }))
  .filter((r) => r.prompt);

const sceneRows = art.scenes
  .map((s) => {
    const label = s.variantOf ? `（变体·复用${s.variantOf}）` : "";
    return { name: s.name + label, prompt: scenePack(s) };
  })
  .filter((r) => r.prompt);

const propRows = (art.props || [])
  .map((p) => ({ name: p.name, prompt: propPack(p) }))
  .filter((r) => r.prompt);

const roundSec = (d) => Math.round(d); // ⛔ 展示一律整秒

// ---- 总控台风格转换：<Picture N>/<Subject N> → @照片名；清首尾帧句式 ----
function slugNameM(name) {
  return String(name || "")
    .replace(/[（(][^）)]*[）)]/g, "")
    .replace(/[\s·、/\\:：，,。.!！?？]/g, "")
    .replace(/[^\u4e00-\u9fa5A-Za-z0-9_\-\.]/g, "")
    .replace(/\.{2,}/g, ".");
}
const toConsolePrompt = (sh) => {
  const sceneByIdM = (id) => (art.scenes || []).find((s) => s.id === id);
  const propByIdM = (id) => (art.props || []).find((p) => p.id === id);
  const charByIdM = (id) => {
    const c = (outline.characters || []).find((x) => x.id === id);
    if (!c) return null;
    const cc = (cast.characters || []).find((x) => x.name === c.name);
    return cc ? { name: c.name } : null;
  };
  const nameOf = (srcId) => {
    if (srcId.startsWith("S")) return (sceneByIdM(srcId) || {}).name || srcId;
    if (srcId.startsWith("C")) return (charByIdM(srcId) || {}).name || srcId;
    if (srcId.startsWith("P")) return (propByIdM(srcId) || {}).name || srcId;
    return srcId;
  };
  const used = new Set();
  const atOf = {};
  const atForSrc = (srcId) => {
    const nm = nameOf(srcId);
    let base = "@" + (slugNameM(nm) || "图" + (used.size + 1));
    let at = base, k = 2;
    while (used.has(at)) at = base + "_" + k++;
    used.add(at);
    atOf[srcId] = at;
    return at;
  };
  // 主体标签映射：<Subject N> -> srcId
  const srcIdOf = {};
  for (const ref of sh.refs || []) {
    const m = ref.match(/<Subject (\d+)>\s*[^（]*?（(?:art\.json|cast\.json)\s*([SCP]\d+)）/) || ref.match(/<Subject (\d+)>\s*[^（]*?（([SCP]\d+)\s*(?:art\.json|cast\.json)）/);
    if (m) srcIdOf["S" + m[1]] = m[2];
  }
  // 首帧/场景图（images/sxx-sheet.png / cxx）也建 @名
  const anchorHit = /images\/([sc]\d+)-sheet\.png/i.exec(sh.firstFrameSource || "");
  if (anchorHit) atForSrc(anchorHit[1].toUpperCase());
  for (const sid of Object.values(srcIdOf)) if (!atOf[sid]) atForSrc(sid);
  let p = String(sh.prompt || "");
  // 删对齐句
  p = p.replace(/For the target video, at 0\.00 seconds into the target video, .*?is fully referenced\.?\s*/s, "");
  p = p.replace(/How the reference pictures align with the target video[\s\S]*?mark of the target video\.?\s*/s, "");
  // <Picture N> → 锚点图 @名（首帧源场景）
  const anchorAt = anchorHit ? atOf[anchorHit[1].toUpperCase()] : null;
  p = p.replace(/<Picture (\d+)>/g, () => anchorAt || "@首帧");
  // <Subject N> → @名
  p = p.replace(/<Subject (\d+)>,\s*/g, (x, n) => (srcIdOf["S" + n] ? atOf[srcIdOf["S" + n]] + ", " : ""));
  p = p.replace(/<Subject (\d+)>(\s*)/g, (x, n, ws) => (srcIdOf["S" + n] ? atOf[srcIdOf["S" + n]] + ws : ""));
  p = p.replace(/ref_image_(\d+)/g, () => "@图");
  p = p.replace(/\s*is fully referenced\.?/g, ".");
  p = p.replace(/\(from \[Shot \d+\]\)/g, "");
  p = p.replace(/The shot begins from [^:]+:\s*/g, "");
  p = p.replace(/The video opens on the exact first frame of this shot:\s*/g, "");
  p = p.replace(/[ \t]{2,}/g, " ");
  p = p.replace(/\s*,(\s*,)+/g, ",");
  p = p.replace(/\n{3,}/g, "\n\n");
  return p.trim();
};

const shotRows = [];
for (const ep of sb.episodes) {
  for (const sh of ep.shots) {
    const d = roundSec(sh.durationSeconds);
    const label = `第${ep.episode}集-${String(sh.shotId).split("-").pop()} · ${d}s · ${sh.mode}`;
    // ⛔ 交付头：复制内容最顶部写 时长：N秒（总控台读取后自动过滤）+ 总控台风格正文
    const prompt = `时长：${d}秒\n\n${toConsolePrompt(sh)}`;
    shotRows.push({ label, prompt });
  }
}

function rowsHtml(rows, key) {
  return rows
    .map(
      (r, i) =>
        `<div class="row"><div class="nm">${esc(r.name || r.label || "")}</div><button class="btn" data-key="${key}" data-idx="${i}">复制提示词</button></div>`
    )
    .join("");
}

const html = `<!DOCTYPE html>
<html lang="zh"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${esc(src)} · 提示词清单（极简版）</title>
<style>
:root{--bg:#f5f5f2;--card:#fff;--line:#ddd;--ink:#222;--dim:#888;--accent:#b3541e}
*{box-sizing:border-box;margin:0;padding:0}
body{background:var(--bg);color:var(--ink);font:14px/1.7 "Microsoft YaHei","PingFang SC",sans-serif;padding:20px;max-width:960px;margin:0 auto}
h1{font-size:22px;margin-bottom:4px}h1 small{color:var(--dim);font-size:13px;font-weight:400}
.sec{margin-top:26px}.sec h2{font-size:17px;border-bottom:2px solid var(--ink);padding-bottom:6px;margin-bottom:12px;display:flex;justify-content:space-between;align-items:center}
.row{display:flex;justify-content:space-between;align-items:center;gap:12px;background:var(--card);border:1px solid var(--line);border-radius:8px;padding:8px 12px;margin-bottom:6px}
.nm{flex:1;min-width:0;word-break:break-all;font-size:14px}
.btn{background:var(--accent);color:#fff;border:none;border-radius:6px;padding:7px 14px;cursor:pointer;font-size:13px;white-space:nowrap;flex:none}
.btn.ghost{background:#666}.btn:hover{opacity:.88}
.sub{color:var(--dim);font-size:12px}
#toast{position:fixed;bottom:24px;left:50%;transform:translateX(-50%);background:#222;color:#fff;padding:9px 20px;border-radius:8px;opacity:0;transition:opacity .25s;pointer-events:none;z-index:9}#toast.show{opacity:1}
</style></head>
<body>
<h1>${esc(src)} · 提示词清单 <small>人物 / 场景 / 道具 / 分镜 一键复制</small></h1>

<div class="sec"><h2>人物出图提示词 <span class="sub">${peopleRows.length} 人</span> <button class="btn ghost" data-copy-all="people">复制全部</button></h2>${rowsHtml(peopleRows, "people")}</div>
<div class="sec"><h2>场景出图提示词 <span class="sub">${sceneRows.length} 景</span> <button class="btn ghost" data-copy-all="scene">复制全部</button></h2>${rowsHtml(sceneRows, "scene")}</div>
<div class="sec"><h2>道具出图提示词 <span class="sub">${propRows.length} 件</span> <button class="btn ghost" data-copy-all="prop">复制全部</button></h2>${rowsHtml(propRows, "prop")}</div>
<div class="sec"><h2>分镜视频提示词 <span class="sub">${shotRows.length} 镜 · 时长整秒</span> <button class="btn ghost" data-copy-all="shot">复制全部</button></h2>
${rowsHtml(shotRows, "shot")}
</div>

<div id="toast">已复制 ✓</div>
<script>
var DATA = ${JSON.stringify({ people: peopleRows, scene: sceneRows, prop: propRows, shot: shotRows }).replace(/<\//g, "<\\/")};
(function(){
  var toast=document.getElementById('toast');
  function show(){toast.classList.add('show');setTimeout(function(){toast.classList.remove('show')},1200)}
  function copy(t){
    function done(){show()}
    function fb(){
      try{
        var a=document.createElement('textarea');a.value=t;a.style.position='fixed';a.style.opacity='0';
        document.body.appendChild(a);a.focus();a.select();a.setSelectionRange(0,999999);
        var ok=document.execCommand('copy');document.body.removeChild(a);
        ok?show():alert('复制失败：浏览器限制 file:// 下自动复制，请手动全选复制。');
      }catch(err){alert('复制失败：'+err.message)}
    }
    if(navigator.clipboard&&window.isSecureContext){navigator.clipboard.writeText(t).then(done,fb)}else{fb()}
  }
  document.addEventListener('click',function(e){
    var b=e.target.closest('.btn[data-key]');
    if(b){var key=b.getAttribute('data-key');var row=(DATA[key]||[])[+b.getAttribute('data-idx')];if(row)copy(row.prompt||row.text||'');return}
    var all=e.target.closest('.btn[data-copy-all]');
    if(all){var key=all.getAttribute('data-copy-all');
      var text=(DATA[key]||[]).map(function(r){return '【'+(r.name||r.label)+'】\\n'+(r.prompt||'')}).join('\\n\\n');
      copy(text);}
  });
})();
</script>
</body></html>`;

fs.writeFileSync(path.join(outDir, src + "-提示词清单.html"), html, "utf8");
console.log("written: " + path.join(outDir, src + "-提示词清单.html"));
console.log("people:", peopleRows.length, "scenes:", sceneRows.length, "props:", propRows.length, "shots:", shotRows.length);
