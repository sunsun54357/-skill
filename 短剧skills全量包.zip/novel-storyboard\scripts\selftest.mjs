// selftest.mjs — novel-storyboard 自测（不调模型、不花额度）
import {
  durLine, beatSeconds, buildSpeakers, seedEpisodes, validateBatch, renderMd, renderHtml, assignRefSlots, applyContinuity, isFirstFrameAnchored,
} from './novel-storyboard.mjs';

let pass = 0, fail = 0;
function ok(cond, label) {
  if (cond) { pass++; }
  else { fail++; console.error(`✗ ${label}`); }
}

// --- 时长折算 ---
ok(Math.abs(durLine('有两个人，跟了我一路。') - 11 / 4.5) < 1e-9, 'durLine 11 字 ÷ 4.5');
ok(Math.abs(durLine('我送你。') - 4 / 4.5) < 1e-9, 'durLine 4 字（含句号）');
ok(Math.abs(durLine('  你 好  ') - 2 / 4.5) < 1e-9, 'durLine 忽略空白');
ok(beatSeconds({ action: 'x' }) === 2.5, '动作拍 = 2.5s');
ok(Math.abs(beatSeconds({ speaker: 'C01', line: '你好。' }) - 3 / 4.5) < 1e-9, '台词拍按字数折算');

// --- 说话人映射（按发声顺序，VO 不占号）---
const outline = { characters: [{ id: 'C01', name: '林砚' }, { id: 'C04', name: '苏晚' }, { id: 'C07', name: '爷爷奶奶' }] };
const epFixture = {
  scenes: [
    { flow: [
      { action: 'a' },
      { speaker: 'C04', line: '第一句。' },
      { action: 'b' },
      { speaker: 'C01', line: '第二句。' },
      { speaker: 'VO', line: '心声。' },
      { speaker: 'C04', line: '第三句。' },
    ] },
  ],
};
const spk = buildSpeakers(epFixture, outline);
ok(spk.length === 2, '说话人只有 2 个（VO 不占号）');
ok(spk[0].id === 'S1' && spk[0].castId === 'C04' && spk[0].name === '苏晚', 'S1 = 第一个发声者苏晚');
ok(spk[1].id === 'S2' && spk[1].castId === 'C01', 'S2 = 林砚');

// --- seed：时长累计与场景光照 ---
const script = { source: 'T', episodes: [
  { ep: 1, targetSeconds: 60, scenes: [
    { sceneId: 'S01', lighting: '傍晚暖光', characters: ['C01'], flow: [
      { action: 'a' }, { action: 'b' }, { speaker: 'C04', line: '有两个人，跟了我一路。' },
    ] },
  ] },
] };
const art = { scenes: [{ id: 'S01', name: '便利店', lighting: [{ state: '傍晚暖光' }], image: { prompt: 'P' } }] };
const seeded = seedEpisodes(script, art, outline, [1]);
ok(seeded.length === 1 && seeded[0].ep === 1, 'seed 取到第 1 集');
ok(Math.abs(seeded[0].totalSeconds - (2.5 + 2.5 + 11 / 4.5)) < 0.01, 'seed 总时长 = 拍之和');
ok(seeded[0].scenes[0].name === '便利店' && seeded[0].scenes[0].lighting === '傍晚暖光', 'seed 带入场景名与光照');
ok(seeded[0].speakers.length === 1 && seeded[0].speakers[0].castId === 'C04', 'seed 说话人映射');

// --- validate：击穿用例 ---
const goodBatch = {
  episode: 1, targetSeconds: 60, speakers: [{ id: 'S1', castId: 'C04' }],
  shots: [{
    shotId: 'E1S01-01', mode: 'I2VA', sceneId: 'S01', lighting: '傍晚暖光',
    startSeconds: 0, endSeconds: 5, durationSeconds: 5,
    prompt: 'For the target video, at 0.00 seconds into the target video, <Picture 1> (from [Shot 1]) is fully referenced.\n\nintegrated_multimodal_description: [Shot 1] body', negativePrompt: 'np', dialogue: [],
  }],
};
// 8–15 镜门：只有 1 镜 → 应报
ok(validateBatch(goodBatch, script, art, outline).some((i) => i.includes('镜头数 1 不在')), '镜头数门拦截');
// 补齐 9 镜，总时长门：每镜 5s × 9 = 45s < 51 → 应报
const nine = { ...goodBatch, shots: Array.from({ length: 9 }, (_, i) => ({ ...goodBatch.shots[0], shotId: `E1S01-0${i + 1}`, startSeconds: i * 5, endSeconds: (i + 1) * 5, durationSeconds: 5 })) };
ok(validateBatch(nine, script, art, outline).some((i) => i.includes('总时长 45.00s 不在')), '总时长门拦截');
// 光照门：未登记状态 → 应报
const badLight = { ...nine, shots: nine.shots.map((s) => ({ ...s, lighting: '正午' })) };
ok(validateBatch(badLight, script, art, outline).some((i) => i.includes('未在 S01 登记')), '光照门拦截');
// 台词门：剧本台词没出现在批次单 → 应报
ok(validateBatch(nine, script, art, outline).some((i) => i.includes('台词缺失「有两个人，跟了我一路。」')), '台词逐字门拦截');
// T2VA 带对齐句 → 应报
const badT2 = { ...nine, shots: nine.shots.map((s) => ({ ...s, mode: 'T2VA', prompt: 'aligns with the 0.00-second mark\n[Shot 1] x' })) };
ok(validateBatch(badT2, script, art, outline).some((i) => i.includes('T2VA 不应有对齐句')), '模式-对齐句门拦截');

// --- 首帧锚定检查（isFirstFrameAnchored）---
ok(isFirstFrameAnchored('integrated_multimodal_description: [Shot 1] The shot begins from <Picture 1>: a medium shot, the boy left of frame...'), '锚定：begins from 通过');
ok(isFirstFrameAnchored('integrated_multimodal_description: [Shot 1] Semi-realistic cinematic short-drama style, painterly rendering with soft blended edges and visible brush texture, matching the established school-corridor design. The shot begins from <Picture 1>: a medium-wide shot...'), '锚定：长风格句后的 begins from 通过');
ok(isFirstFrameAnchored('The video opens on the exact first frame of this shot, continuing the previous shot\'s final state: the boy at the door...'), '锚定：opens on 通过');
ok(isFirstFrameAnchored('The scene settles into the exact frame shown in <Picture 1>: the empty alley...'), '锚定：settles into 通过');
ok(!isFirstFrameAnchored('integrated_multimodal_description: [Shot 1] Continuing in the store, the girl steps closer and says...'), '未锚定：Continuing in 拦截');
ok(!isFirstFrameAnchored(''), '空提示词拦截');
ok(validateBatch(nine, script, art, outline).some((i) => i.includes('未从首帧写起')), '首帧锚定门拦截（正文未锚定）');

// --- assignRefSlots：ref_image_N 槽位 + 提示词改写 ---
const shotSlots = {
  shotId: 'E1S01-01', mode: 'I2VA', sceneId: 'S01', scene: '便利店', lighting: '傍晚暖光',
  firstFrameSource: 'images/s01-sheet.png（art.json S01 便利店设定图，待 codex 出图）',
  refs: ['<Subject 1> 便利店（art.json S01）', '<Subject 2> 林砚（cast.json C01）', '<Subject 5> 混混（cast.json C06）'],
  prompt: 'For the target video, at 0.00 seconds into the target video, <Picture 1> (from [Shot 1]) is fully referenced.\n\nintegrated_multimodal_description: [Shot 1] The shot begins from <Picture 1>, the interior of <Subject 1>. <Subject 2>, the slender teenage boy, enters. <Subject 5>, the thugs, follow.',
};
const castForSlots = { characters: [{ name: '林砚', image: { prompt: 'LIN' } }] };
const { slots, transform } = assignRefSlots(shotSlots, art, castForSlots, outline);
ok(slots.length === 2, 'refs 槽位：首帧 + 有形象卡的林砚（混混无卡不入槽）');
ok(slots[0].refId === 'ref_image_1' && slots[0].role === '首帧', '锚点占 ref_image_1');
ok(slots[1].refId === 'ref_image_2' && slots[1].name === '林砚形象图', '角色占 ref_image_2');
const tp = transform(shotSlots.prompt);
ok(tp.includes('ref_image_1') && !tp.includes('<Picture 1>'), '改写：<Picture 1> → ref_image_1');
ok(tp.includes('ref_image_2') && !tp.includes('<Subject 2>'), '改写：<Subject 2> → ref_image_2');
ok(!tp.includes('<Subject 5>'), '无槽位主体标签被移除');
ok(tp.includes('the thugs'), '移除标签后描述文字保留');

// --- applyContinuity：上一镜尾帧 = 本镜首帧（排最后 + 首帧声明）---
const prevShot = { shotId: 'E1S01-00' };
const c1 = applyContinuity(shotSlots, prevShot, slots, tp);
ok(c1.slots.length === 3 && c1.slots[2].continuity === true && c1.slots[2].role.includes('上一镜尾帧'), '续接槽位追加在最后');
ok(c1.slots[2].refId === 'ref_image_3', '续接槽位编号接续');
ok(c1.prompt.startsWith('For the target video, at 0.00 seconds into the target video, ref_image_3 (from [Shot 1]) is fully referenced'), '续接首帧声明在提示词最前');
ok(c1.prompt.includes('last frame of the previous shot') && c1.prompt.includes('exact first frame'), '声明含上一镜尾帧与 exact first frame');
ok(!c1.prompt.includes('ref_image_1 (from [Shot 1]) is fully referenced') && c1.prompt.includes('design reference image'), 'I2VA 原首帧让位为设计参考，避免双首帧');
const c2 = applyContinuity({ ...shotSlots, mode: 'FL2VA' }, prevShot, slots, tp);
ok(c2.slots.length === slots.length && c2.prompt === tp, 'FL2VA 已有起帧=上一镜尾帧，不重复追加');
ok(c2.slots[0].src === 'images/E1S01-00-tail.png', 'FL2VA 起帧槽位挂上一镜尾帧图');
const c3 = applyContinuity(shotSlots, null, slots, tp);
ok(c3.slots.length === slots.length, '无上一镜（每集首镜）不追加');

// --- render 关键结构 ---
const merged = {
  source: 'T', style: 'realistic',
  episodes: [{
    episode: 1, targetSeconds: 60, totalSeconds: 55, speakers: [{ id: 'S1', name: '苏晚' }],
    shots: [{
      shotId: 'E1S01-01', mode: 'I2VA', sceneId: 'S01', scene: '便利店', lighting: '傍晚暖光',
      startSeconds: 0, endSeconds: 5, durationSeconds: 5, firstFrameSource: 'images/s01-sheet.png（待出图）',
      refs: ['<Subject 1> 便利店（art.json S01）'],
      prompt: 'For the target video, at 0.00 seconds into the target video, <Picture 1> (from [Shot 1]) is fully referenced.\n\nintegrated_multimodal_description: [Shot 1] Semi-realistic cinematic short-drama style. The shot begins from <Picture 1>, the interior of <Subject 1>, the street-side convenience store at early dusk.', negativePrompt: 'np', dialogue: [{ speakerId: 'S1', name: '苏晚', text: '你好。' }],
    }, {
      shotId: 'E1S01-02', mode: 'T2VA', sceneId: 'S01', scene: '便利店', lighting: '傍晚暖光',
      startSeconds: 5, endSeconds: 12.44, durationSeconds: 7.44,
      refs: ['<Subject 1> 便利店（art.json S01）'],
      prompt: 'integrated_multimodal_description: [Shot 1] Semi-realistic cinematic short-drama style. Continuing in <Subject 1>, the convenience store, the girl steps closer.', negativePrompt: 'np', dialogue: [{ speakerId: 'S1', name: '苏晚', text: '你好。' }],
    }],
  }],
};
const md = renderMd(merged, art, castForSlots, outline);
ok(md.includes('E1S01-01') && md.includes('苏晚：你好。') && md.includes('## 第 1 集'), 'renderMd 分镜表结构');
ok(md.includes('ref_image_1（首帧·便利店设定图）') && md.includes('ref_image_1 (from [Shot 1])'), 'renderMd 参考图槽位 + 改写提示词');
ok(md.includes('上一镜尾帧 = 本镜首帧（续接）'), 'renderMd 续接槽位');
const html = renderHtml(merged, art, castForSlots, outline, script);
ok(html.includes('一键复制提示词') && html.includes('ref_image_1') && html.includes('复制全集'), 'renderHtml 一键复制 + ref_image_N');
ok(html.includes('images/s01-sheet.png') || html.includes('便利店设定图'), 'renderHtml 图片来源解析');
ok(html.includes('cast-line') && html.includes('人物') && html.includes('陈设'), 'renderHtml 出现清单（场景/人物/道具/陈设）');
ok(html.includes('苏晚（S1）') && html.includes('便利店（S01）'), 'renderHtml 出现清单内容解析');
ok(html.includes('首帧锚定 ✓'), 'renderHtml 首帧锚定徽章');
ok(!html.includes('<Picture 1>') && !html.includes('@图片1'), 'renderHtml 不再出现 <Picture N>/@图片');
ok((html.match(/上一镜尾帧 = 本镜首帧（续接）/g) || []).length === 1, 'renderHtml 只有第二镜带续接槽位（首镜无上一镜）');
ok(html.includes('ref_image_2 (from [Shot 1]) is fully referenced — this image is the last frame of the previous shot and is the exact first frame of this video'), 'renderHtml 续接首帧声明（H3 格式）');

// --- 尾帧图存在时，续接槽位显示预览 ---
import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
const tmpDir = fs.mkdtempSync(path.join(os.tmpdir(), 'sb-test-'));
fs.mkdirSync(path.join(tmpDir, 'images'), { recursive: true });
fs.writeFileSync(path.join(tmpDir, 'images', 'E1S01-01-tail.png'), 'fake-png');
const html2 = renderHtml(merged, art, castForSlots, outline, script, tmpDir);
ok(html2.includes('tail-preview') && html2.includes('images/E1S01-01-tail.png'), 'renderHtml 尾帧图预览（已提取时显示 <img>）');
fs.rmSync(tmpDir, { recursive: true, force: true });

console.log(`✓ ${pass} 项通过${fail ? `，✗ ${fail} 项失败` : ''}`);
if (fail) process.exit(1);
