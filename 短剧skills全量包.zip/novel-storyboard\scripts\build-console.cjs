const fs = require("fs");
const path = require("path");
const stripBom = (s) => s.replace(/^\uFEFF/, "");

// 用法：node build-console.mjs <剧名>-分镜.json --art <art.json> --cast <cast.json> --outline <outline.json> [--out <输出目录>]
function parseArgs(argv) {
  const a = { _: [] };
  for (let i = 0; i < argv.length; i++) {
    const x = argv[i];
    if (x.startsWith("--")) a[x.slice(2)] = argv[++i];
    else a._.push(x);
  }
  return a;
}
const a = parseArgs(process.argv.slice(2));
const mergedPath = a._[0];
if (!mergedPath || !a.art || !a.cast || !a.outline) {
  console.error("用法：node build-console.mjs <剧名>-分镜.json --art <art.json> --cast <cast.json> --outline <outline.json> [--out <目录>]");
  process.exit(1);
}
const outDir = a.out || path.dirname(path.resolve(mergedPath));
const merged = JSON.parse(stripBom(fs.readFileSync(mergedPath, "utf8")));
const art = JSON.parse(stripBom(fs.readFileSync(a.art, "utf8")));
const cast = JSON.parse(stripBom(fs.readFileSync(a.cast, "utf8")));
const outline = JSON.parse(stripBom(fs.readFileSync(a.outline, "utf8")));

// ---- 命名表：id -> @名字（直接用提示词里的实际名字，slug 化保证无空格/全角标点）----
const charName = {};
const sceneName = {};
const propName = {};
function slugName(name) {
  // 去括号注释、去空格与分隔符，保留中文/字母/数字/_-.
  return String(name || "")
    .replace(/[（(][^）)]*[）)]/g, "")
    .replace(/[\s·、/\\:：，,。.!！?？]/g, "")
    .replace(/[^\u4e00-\u9fa5A-Za-z0-9_\-\.]/g, "")
    .replace(/\.{2,}/g, ".");
}
function atFor(id, rawName) {
  const n = slugName(rawName);
  return "@" + (n || id);
}
const charById = (id) => {
  const c = (outline.characters || []).find((x) => x.id === id);
  if (!c) return null;
  const cc = (cast.characters || []).find((x) => x.name === c.name);
  return cc ? { name: c.name, image: cc.image } : null;
};

// ---- 槽位分配（总控台版）：返回槽位数组 + transform ----
function assignConsoleSlots(sh) {
  const MAX = 9;
  const sceneById = (id) => (art.scenes || []).find((s) => s.id === id);
  const propById = (id) => (art.props || []).find((p) => p.id === id);
  const localHits = (src) => {
    const hits = [];
    const re = /images\/([sc]\d+)-sheet\.png/gi;
    let m;
    while ((m = re.exec(src || ""))) hits.push(m[1].toUpperCase());
    return hits;
  };
  const assigned = new Set();
  const slots = []; // {at, role, name, gen, sourceId, kind}
  const slotByRef = {};
  const add = (kind, role, name, gen, sourceId) => {
    if (slots.length >= MAX || assigned.has(sourceId)) return null;
    assigned.add(sourceId);
    slots.push({ at: "@图" + (slots.length + 1), role, name, gen, sourceId, kind });
    return slots.length; // 1-based index -> @图N placeholder
  };
  // 1) 图像模式锚点
  const hits = localHits(sh.firstFrameSource);
  if (sh.mode === "I2VA" && hits[0]) {
    const id = hits[0];
    const info = id.startsWith("S") ? sceneById(id) : charById(id);
    const r = add("anchor", "首帧设定图", `${(info || {}).name || id}（设定图）`, (info || {}).image?.prompt || null, id);
    if (r) slotByRef.P1 = r;
  } else if (sh.mode === "L2VA") {
    const id = hits[0];
    const sc = id ? sceneById(id) : sceneById(sh.sceneId);
    const r = add("anchor", "末帧收敛", (sc || {}).name ? `${sc.name}（主视角）` : "（本场场景主视角图）", (sc || {}).image?.prompt || null, id || "__l2__");
    if (r) slotByRef.P1 = r;
  } else if (sh.mode === "FL2VA") {
    const r1 = add("anchor", "起帧", "上一镜尾帧（续接）", null, "__fl1__");
    if (r1) slotByRef.P1 = r1;
    const id = hits[0];
    const sc = id ? sceneById(id) : sceneById(sh.sceneId);
    const r2 = add("anchor", "末帧", (sc || {}).name ? `${sc.name}（主视角）` : "（本场场景主视角图）", (sc || {}).image?.prompt || null, id || "__fl2__");
    if (r2) slotByRef.P2 = r2;
  }
  // 2) refs 主体
  for (const ref of sh.refs || []) {
    const m = ref.match(/<Subject (\d+)>\s*([^（]*?)（(?:art\.json|cast\.json)\s*([SCP]\d+)）/) || ref.match(/<Subject (\d+)>\s*([^（]*?)（([SCP]\d+)\s*(?:art\.json|cast\.json)）/);
    if (!m) continue;
    const num = m[1];
    const srcId = m[3];
    let role = null, name = null, gen = null, kind = null;
    if (srcId.startsWith("S")) {
      const sc = sceneById(srcId);
      if (!sc) continue;
      role = "场景"; name = sc.name; gen = sc.image?.prompt || null; kind = "scene";
      const r = add(kind, role, name, gen, srcId);
      if (r) slotByRef["S" + num] = r;
    } else if (srcId.startsWith("C")) {
      const c = charById(srcId);
      if (!c) continue;
      role = "角色"; name = c.name; gen = c.image?.prompt || null; kind = "char";
      const r = add(kind, role, name, gen, srcId);
      if (r) slotByRef["S" + num] = r;
    } else {
      const p = propById(srcId);
      if (!p) continue;
      role = "道具"; name = p.name; gen = p.image?.prompt || null; kind = "prop";
      const r = add(kind, role, name, gen, srcId);
      if (r) slotByRef["S" + num] = r;
    }
  }
  // 3) 槽位命名：@名字 = 提示词里该主体的实际名字（slug 化），保证一镜内名字唯一
  for (let i = 0; i < slots.length; i++) {
    const s = slots[i];
    const at = atFor(s.sourceId, s.name);
    // 一镜内去重：同名加后缀
    let finalAt = at;
    let k = 2;
    while (slots.some((x, j) => j < i && x.at === finalAt)) finalAt = at + "_" + k++;
    s.at = finalAt;
    s.disp = s.name;
  }
  // transform（总控台风格）：删除官方对齐句与 H3 句式残留，
  // <Picture N>/<Subject N> → @照片名；正文保留描述文字与 [Shot N] 切点。
  const refToAt = {}; // slot index+1 -> at
  slots.forEach((s, i) => { refToAt[i + 1] = s.at; });
  const transform = (prompt) => {
    let p = String(prompt || "");
    // 1) 整段删除官方对齐句（I2VA/FL2VA/L2VA 首行）
    p = p.replace(
      /For the target video, at 0\.00 seconds into the target video, .*?is fully referenced\.?\s*/s,
      ""
    );
    p = p.replace(/How the reference pictures align with the target video[\s\S]*?mark of the target video\.?\s*/s, "");
    // 2) 标签替换：<Picture N>/<Subject N> → @名
    p = p.replace(/<Picture (\d+)>/g, (mm, n) => (slotByRef["P" + n] ? slots[slotByRef["P" + n] - 1].at : mm));
    p = p.replace(/<Subject (\d+)>,\s*/g, (mm, n) => (slotByRef["S" + n] ? `${slots[slotByRef["S" + n] - 1].at}, ` : ""));
    p = p.replace(/<Subject (\d+)>(\s*)/g, (mm, n, ws) => (slotByRef["S" + n] ? `${slots[slotByRef["S" + n] - 1].at}${ws}` : ""));
    // 3) 清官方句式残留：is fully referenced / begins from <Picture N>: / (from [Shot N]) / is the design reference image
    p = p.replace(/\s*is fully referenced\.?/g, ".");
    p = p.replace(/\(from \[Shot \d+\]\)/g, "");
    p = p.replace(/The shot begins from [^:]+:\s*/g, "");
    p = p.replace(/The video opens on the exact first frame of this shot:\s*/g, "");
    p = p.replace(/ref_image_(\d+)/g, (mm, n) => refToAt[n] || mm);
    // 4) 清理空白
    p = p.replace(/[ \t]{2,}/g, " ");
    p = p.replace(/\s*,(\s*,)+/g, ",");
    p = p.replace(/\n{3,}/g, "\n\n");
    return p.trim();
  };
  return { slots, transform };
}

// ---- 渲染总控台版 HTML ----
const esc = (s) => String(s ?? "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
let totalShots = 0;
merged.episodes.forEach((ep) => { totalShots += ep.shots.length; });
const modeColors = { I2VA: "#4da3ff", T2VA: "#9aa5b1", FL2VA: "#ffb84d", L2VA: "#7bd88f" };
let sections = "";
let allPrompts = "";
for (const ep of merged.episodes) {
  const epTotal = ep.totalSeconds != null ? ep.totalSeconds : ep.shots.reduce((s, sh) => s + (sh.durationSeconds || 0), 0);
  let cards = "";
  let epCopy = "";
  for (const sh of ep.shots) {
    const { slots, transform } = assignConsoleSlots(sh);
    let tp = transform(sh.prompt);
    // 续接：非 FL2VA 首帧锚定句由原 prompt 自带（对齐句已在分镜里写了 is fully referenced），保留即可
    let imgHtml = "";
    for (const s of slots) {
      imgHtml += `<div class="img-row"><span class="img-tag">${esc(s.at)}</span><span class="img-role">${esc(s.role)}</span><span class="img-name">${esc(s.disp)}</span>`;
      if (s.gen) imgHtml += `<details class="img-gen"><summary>图片生成提示词（${esc(s.disp)}，复制去出图）</summary><pre>${esc(s.gen)}</pre><button class="btn copy" data-copy="${esc(s.gen)}">复制图片提示词</button></details>`;
      imgHtml += `</div>`;
    }
    if (!slots.length) imgHtml = `<div class="img-row none">纯文本生成 · 无需图片</div>`;
    const dia = (sh.dialogue || []).map((d) => `${d.name}：${d.text}`).join("<br>");
    // 统计 @ 数
    const atCount = (tp.match(/@[\u4e00-\u9fa5A-Za-z0-9_\-\.]+/g) || []).length;
    const warning = atCount > 9 ? `<span class="warn">⚠ @数 ${atCount} 超 9</span>` : "";
    const durSec = Math.round(sh.durationSeconds); // ⛔ 整秒
    // ⛔ 交付头：复制文本最顶部写 时长：N秒（总控台读取后自动过滤）
    const copyText = `时长：${durSec}秒\n\n${tp}`;
    cards += `<div class="card" id="${esc(sh.shotId)}"><div class="card-head"><span class="badge shot">${esc(sh.shotId)}</span><span class="badge mode" style="background:${modeColors[sh.mode] || "#666"}">${esc(sh.mode)}</span><span class="scene">${esc(sh.scene)} · ${esc(sh.lighting)}</span><span class="dur">${durSec}s</span><span class="time">${Math.round(sh.startSeconds)}–${Math.round(sh.endSeconds)}s</span><span class="atcount">@×${atCount}</span>${warning}<button class="btn copy main" data-copy="${esc(copyText)}">一键复制提示词</button></div><div class="img-box">${imgHtml}</div>${dia ? `<div class="dialogue">🎙 ${dia}</div>` : ""}<details class="prompt-box"><summary>内容（H3 总控台格式，照片用 @名字 引用）</summary><pre>${esc(copyText)}</pre><button class="btn copy" data-copy="${esc(copyText)}">复制提示词</button></details></div>`;
    epCopy += `【${sh.shotId}】${sh.mode} · ${durSec}s\n${copyText}\n\n`;
  }
  sections += `<section class="ep-section" id="ep-${ep.episode}"><h2>第 ${ep.episode} 集（${Math.round(epTotal)}s / 目标 ${ep.targetSeconds}s）</h2><button class="btn copy" data-copy="${esc(epCopy)}">复制本集全部提示词</button>${cards}</section>`;
  allPrompts += `===== 第 ${ep.episode} 集 =====\n${epCopy}`;
}
const html = `<!DOCTYPE html>
<html lang="zh"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${esc(merged.source)} · H3 总控台分镜提示词</title>
<style>
:root{--bg:#0f1216;--card:#171c23;--card2:#1d242e;--line:#2a333f;--text:#e8edf2;--dim:#8b96a5;--accent:#ffb84d}*{box-sizing:border-box;margin:0;padding:0}
body{background:var(--bg);color:var(--text);font:14px/1.6 "Microsoft YaHei","PingFang SC",sans-serif;padding:24px}
header{max-width:1080px;margin:0 auto 20px}h1{font-size:24px}
.note{color:var(--dim);font-size:12px;margin-top:6px;background:var(--card2);border:1px solid var(--line);border-radius:8px;padding:12px}
.toolbar{margin-top:12px}
.ep-section{max-width:1080px;margin:0 auto 32px}.ep-section h2{font-size:18px;border-bottom:1px solid var(--line);padding-bottom:8px;margin-bottom:10px}
.card{background:var(--card);border:1px solid var(--line);border-radius:10px;margin-bottom:14px;overflow:hidden}
.card-head{display:flex;align-items:center;gap:10px;padding:10px 14px;border-bottom:1px solid var(--line);flex-wrap:wrap}
.badge{border-radius:5px;padding:2px 8px;font-size:12px;font-weight:600}.badge.shot{background:#2c3747;color:#ffb84d;font-family:Consolas,monospace}.badge.mode{color:#0b0e12}
.scene{font-size:13px}.dur{font-size:16px;font-weight:700;color:var(--accent)}.time{color:var(--dim);font-size:12px;font-family:Consolas,monospace}
.atcount{color:#ffd479;font-size:12px;font-family:Consolas,monospace}.warn{color:#ff7b7b;font-weight:700}
.btn{background:var(--accent);color:#0b0e12;border:none;border-radius:6px;padding:6px 12px;cursor:pointer;font-size:12px;font-weight:600}
.btn.copy{background:#2c3747;color:var(--accent);border:1px solid #3a4a5e}.btn.copy:hover{background:#3a4a5e}.btn.main{margin-left:auto}
.photo-list{padding:8px 14px;background:#2a2413;color:#ffd479;font-size:13px;border-bottom:1px solid var(--line)}
.img-box{padding:8px 14px;border-bottom:1px solid var(--line);background:var(--card2)}
.img-row{display:flex;align-items:center;gap:8px;font-size:13px;flex-wrap:wrap}.img-row.none{color:var(--dim);font-style:italic}
.img-tag{background:#3d2f1a;color:#ffb84d;border-radius:4px;padding:1px 6px;font-family:Consolas,monospace;font-size:12px}
.img-role{color:#7bd88f;font-size:12px}.img-name{color:var(--text)}
.img-gen{margin-top:4px;font-size:12px}.img-gen summary{color:var(--accent);cursor:pointer}
.img-gen pre,.prompt-box pre{background:#0b0e12;border:1px solid var(--line);border-radius:6px;padding:10px;white-space:pre-wrap;word-break:break-word;font-family:Consolas,monospace;font-size:12px;color:#cdd6e0;margin:6px 0}
.dialogue{padding:6px 14px;font-size:13px;color:#ffd479}
.prompt-box{padding:0 14px 12px}.prompt-box summary{color:var(--accent);cursor:pointer;font-size:12px;padding-top:6px}
#toast{position:fixed;bottom:24px;left:50%;transform:translateX(-50%);background:var(--accent);color:#0b0e12;padding:8px 18px;border-radius:8px;font-weight:600;opacity:0;transition:opacity .25s;pointer-events:none}#toast.show{opacity:1}
@media(max-width:720px){.btn.main{margin-left:0}}
</style></head>
<body>
<header><h1>🎬 ${esc(merged.source)} · H3 总控台分镜提示词</h1>
<div class="note">用法：① 按每镜卡片里的 <b>@名字</b> 槽位去总控台照片库上传/改名（@名就是照片库名）→ ② 点「一键复制提示词」→ ③ 粘贴进总控台提交。提示词顶部 <b>时长：N秒</b> 供总控台读时长、提交时自动过滤；正文里的 <b>@名字</b> 自动按出现顺序变成 ref_image_0~8，第一个 @ 即主图。<b>无需手动选图。</b>一镜 ≤9 个 @；同一张图 @ 多次只占一个槽。</div>
<div class="toolbar"><button class="btn copy" data-copy="${esc(allPrompts)}">复制全集提示词（${totalShots} 镜）</button></div></header>
${sections}
<div id="toast">已复制到剪贴板 ✓</div>
<script>
(function(){var t=document.getElementById('toast');function show(){t.classList.add('show');setTimeout(function(){t.classList.remove('show')},1400)}
function copy(text){if(navigator.clipboard&&window.isSecureContext){navigator.clipboard.writeText(text).then(show,function(){fb(text)})}else{fb(text)}}
function fb(text){var a=document.createElement('textarea');a.value=text;a.style.position='fixed';a.style.opacity='0';document.body.appendChild(a);a.select();try{document.execCommand('copy');show()}catch(e){alert('复制失败')}document.body.removeChild(a)}
document.addEventListener('click',function(e){var b=e.target.closest('.copy[data-copy]');if(b)copy(b.getAttribute('data-copy'))});})();
</script>
</body></html>`;
const outBase = path.join(outDir, merged.source || "剧名");
fs.writeFileSync(outBase + "-H3分镜提示词-总控台.html", html, "utf8");
console.log("written: " + outBase + "-H3分镜提示词-总控台.html");
console.log("shots:", totalShots);
