---
name: novel-storyboard
version: 1.0.0
description: |
  给 AI 短剧出分镜层交付物：镜号、单镜头时长、模式（T2VA / I2VA / FL2VA / L2VA）、
  H3 格式视频提示词、首帧来源、生成批次单，以及一键复制网页版（H3分镜提示词.html）。
  上游是 novel-script（剧本），配合 novel-outline / novel-art / novel-characters 四件套 JSON；
  产出 <剧名>-分镜.json + <剧名>-分镜表.md + <剧名>-H3分镜提示词.html。
  13 道质量门由脚本确定性检查（镜头数 8-15、总时长 60±15%、起止链连续、单镜 ≥1.5s、
  光照已登记、台词逐字覆盖、说话人映射合法、模式与动作匹配、首帧锚定等），不靠模型自觉；
  零依赖零 API key，node 直接跑。
  Use when asked to 分镜、分镜表、H3分镜提示词、镜号、镜头提示词、storyboard、分镜网页版、批量生成视频提示词。
---

# 短剧分镜

给 AI 短剧出**分镜层交付物**：镜号、单镜头时长、模式（T2VA / I2VA / FL2VA / L2VA）、H3 格式视频提示词、首帧来源、生成批次单，以及**一键复制网页版**。

**位置**：novel-script 的下一层。剧本管戏，分镜管拍——本 skill 只有镜号、时长、提示词、批次单，不写剧情、不做角色/场景设定、不出图。

`{baseDir}` = 本文件所在目录。脚本 `{baseDir}/scripts/novel-storyboard.mjs`，零依赖，`node` 直接跑。

**交付物三件套（⛔ 网页版必出）**：

```
<输出目录>/
├── <剧名>-分镜.json             机器可读批次单（分段 + 段内多镜头，见 examples/）
├── <剧名>-分镜表.md             可读分镜表 + 每段完整提示词
└── <剧名>-H3分镜提示词.html     ⛔ 一键复制网页版：集导航 + 每段「时长/内容」+ 复制按钮
```

**成片方式 = 分段拼接（seedance 做法）**：不是一镜一条视频，而是把一场戏拆成**若干「视频段」**，每段 ≤10 秒、自由时长、段内多镜头多视角一次生成；段与段之间用**画面衔接点**（上一段尾状态 = 下一段开始状态）和「延长」拼接成完整戏。

---

### Step 0 — 输入检查

四件套 JSON 缺一不可：

| 文件 | 用途 |
| --- | --- |
| `<剧名>-script.json` | **直接上游**：节拍流、台词、单集目标秒数 |
| `<剧名>-outline.json` | 角色 C 编号 → 名字（cast.json 没有 id 字段） |
| `<剧名>-art.json` | 场景 id/名称/**光照状态**/场景图片提示词 |
| `<剧名>-cast.json` | 角色名 → 形象提示词（图片生成提示词来源） |

缺哪个先跑对应 skill；从小说全流程按 characters → outline → art → script → 本 skill 顺序。输出目录默认原剧目录。

### Step 1 — seed 骨架（脚本确定性搬运 ⛔）

```bash
node {baseDir}/scripts/novel-storyboard.mjs seed <script.json> \
  --art <art.json> --outline <outline.json> --eps 1-3 > <workdir>/seed.json
```

确定性算好，**不要模型重算**：逐拍时长（台词 = 非空白字数 ÷ 4.5，动作 = 2.5 秒/拍）、每场登记场景与光照、按全片发声顺序排 `(Sx)` 映射。

### Step 2 — 逐集拆段写提示词（模型工作）⛔ 分段拼接，不逐镜

**每集一份**（支持子代理并发，同一条消息全部发出）。每份任务拿到：seed 骨架、该集节拍流、`references/format.md`（灯光/摄像角度/镜头语言/H3 格式全表，读它照着写）。

**核心单位是「视频段」，不是「镜头」**：

- 一场戏按叙事节奏拆成若干**视频段**，每段 ≤10 秒、自由时长（5/6/8/9/10s 皆可，不强行等分）
- **每段 = 一条独立提示词**，`detailed_description` 内部含多个镜头（4–6 个快切，每镜 1.5–2.5s），镜头之间用切点时间戳连接（`[镜头1]` → `[镜头2] 在 00:01.500 处` …）
- 段内镜头覆盖不同景别/机位/视角（特写→全景→仰拍→俯视…），让一段 10 秒也有画面推进
- **段与段之间写死「画面衔接点」**：段 A 的结尾状态 = 段 B 的开始状态（上一段停在"她抬手推门"，下一段就从"门推开、她迈进去"开始）；后续段提示词顶部用「承接上一段结尾」注明
- 台词逐字来自 script.json，`<d>[Chinese] ...</d>`

产出 `<workdir>/ep<N>.json`，每条 `segment`（视频段）：

| 字段 | 规则 |
| --- | --- |
| `segmentId` | `E<集>S<场>-<段序号>`（如 E1S01-1） |
| `durationSeconds` | 该段总时长 ≤10s（自由，整秒展示） |
| `shots` | 段内镜头数组，每条含 `shotId`（E1S01-1-1）、`fromSeconds`（段内切点，首镜 0）、镜头语言（景别/机位/运镜） |
| `sceneId` / `lighting` | 只允许 art.json 已登记的光照状态 |
| `refs` | `@照片名（角色/场景/道具，来源 json）`——正文里需要照片直接写 `@照片名` |
| `prompt` | 中文正文六段式（有参考照片时）：`subject_definitions` / `summary` / `retention_analysis` / `detailed_description` / `overall_soundscape` / `non_diegetic_music`；照片来源标 `@照片名`，正文主体用文字指代（不要 `<Subject N>`/`<Picture N>`/`ref_image_N`）；无参考照片用三核心字段。`summary` 以 `[reference_generation]` 开头并注明段序（第几段/共几段）。`detailed_description` 内按镜头时间戳写，风格见 `references/format.md` 与中文多镜头示例 |
| `continuity` | 非首段的衔接说明：承接上一段尾状态（画面/位置/动作从哪续），供生成时用「延长」接 |
| `dialogue` | 本段台词逐字（无则空） |

**每段 ≤10 秒规则**：总时长折算后每段落在 4–10s；台词 4.5 字/秒、动作 2.5 秒/拍。写完删掉 seed 里的提示残留。

### Step 2.5 — 中文多镜头段写法（⛔ 写作基准，模仿此风格）

一段 ≤10s 的提示词，中文正文，段内多镜头。格式：

```text
subject_definitions:
<subject 1> 的外观形象与服装完全来自 @徒隐言，特征为[外观摘要]。
<subject 2> 是 <subject 1> 案上的 @金丝木盒（深色陈年硬木、错金缠枝卷云纹、盒缝暗红旧渍）。

summary:
[reference_generation] 6 秒写实古风冷开场。<subject 1> 于 @天渊萧夙殿 殿内案前，指腹掀开 <subject 2> 盒盖一线。

retention_analysis:
<subject 1>（出现在 [镜头1] 至 [镜头3]）：fully_preserved - 外观全程严格保留。
<subject 2>（出现在 [镜头1] 至 [镜头3]）：fully_preserved - 木盒错金纹与旧渍保持。

detailed_description:
目标视频为写实暗黑古风，冷银灰主调，烛火幽蓝。
[镜头1] 大特写：<subject 2> 盒盖被掀开一线，暗红衬垫上一颗心仍在搏动，血丝洇出。
[镜头2] 在 00:01.500 处，急拉中景：<subject 1> 垂眸盯着盒心，朱砂痣在冷光里一暗，咔地合上盒盖。
[镜头3] 在 00:03.500 处，特写：他平缓将 <subject 2> 滑入袖中，袖口垂落掩住棱角。

overall_soundscape:
幽深殿内极静，仅心跳湿响、盒盖脆响、衣料摩擦。

non_diegetic_music:
低弦长音压底，随镜头 3 渐隐。
```

要点：正文中文；`<subject N>` 只作简短指代（来源标 `@照片名`）；段内多镜头用时间戳推进，覆盖不同景别/机位；段与段之间在 `summary` 或 `continuity` 注明承接上一段尾状态。

### Step 3 — 校验 ⛔ 不能跳

```bash
node {baseDir}/scripts/novel-storyboard.mjs validate <workdir>/ep<N>.json \
  --script <script.json> --art <art.json> --outline <outline.json>
```

质量门全是代码：镜头数 8–15、总时长 60±15%、起止链连续、单镜 ≥1.5s、光照已登记、场景/角色存在、台词逐字覆盖（剧本每句台词都出现在批次单里）、说话人映射合法、模式与动作匹配（没有状态转变的动作别硬凑 FL2VA）、提示词含 `[Shot 1]`、图像模式含对齐句、T2VA 无对齐句、**提示词正文从首帧写起**（首帧锚定：去掉对齐句后开头 200 字符须含 `opens on / begins from / exact first frame / settles into` 等，见 `references/format.md` §9）。有违规逐条修，改完重跑，直到通过。

### Step 4 — 合并 + 渲染 ⛔ 网页版必出

```bash
node {baseDir}/scripts/novel-storyboard.mjs merge <workdir> \
  --out <输出目录>/<剧名>-分镜.json
node {baseDir}/scripts/novel-storyboard.mjs render <剧名>-分镜.json \
  --art <art.json> --cast <cast.json> --outline <outline.json> --script <script.json> --out <输出目录>
```

- `merge`：按集合并、跨集校验、落盘 `分镜.json`
- `render`：生成 `分镜表.md` + **`H3分镜提示词.html`**（⛔ 必须交付，用户要的就是这个）
- 网页版自动：集导航、每镜卡片三要素（**几秒**=时长+起止 / **照片**=`ref_image_1~8` 槽位+用途+图片生成提示词 / **内容**=完整 H3 提示词，图片引用已改写为 `ref_image_N`）、**续接参考图**（非首镜最末槽位 = 上一镜尾帧 = 本镜首帧，提示词按 H3 格式声明 `is fully referenced ... exact first frame`）、出现清单（场景/人物/道具/陈设）、每镜/每集/全集一键复制、负面词折叠

**提取尾帧（视频生成后，续接图自动回填）**：

```bash
# 生成的视频按镜号命名下载到 videos/ 目录（如 E1S01-02.mp4），然后：
node {baseDir}/scripts/novel-storyboard.mjs extract videos/ --out <输出目录>/images
```

- 每支视频最后一帧 → `images/<镜号>-tail.png`；网页版续接槽位检测到该文件后自动显示预览图（`<img class="tail-preview">`）
- FL2VA 的起帧槽位同样挂上一镜的尾帧图
- 依赖 Python + opencv（`cv2`）；脚本已处理中文路径（自动暂存 ASCII 临时路径读写）；已存在的输出自动跳过（幂等）

### Step 4.5 — H3 总控台适配（⛔ 有总控台需求时必出）

用户要在 **H3 总控台**（http://localhost:8188/desk）里直接用的，除了原生 `ref_image_N` 版网页，另出一份**总控台版**：`<剧名>-H3分镜提示词-总控台.html`。规则见 `{baseDir}/references/console-format.md`，核心是**两层结构**：

- **第 1 层（总控台包装，复制文本最顶部一行）**：`时长：N秒`（N = 该镜整秒，总控台读时长、提交时自动过滤）；正文照片来源用 **`@照片库名`** 标注（第一个 @ = ref_image_0 主图、最多 9 个、名字与照片库一致；用户给了照片库名就用用户的，没给才用主体实际名 slug 化）；**不加【本镜照片】清单**
- **第 2 层（MiniMax 官方正文）**：结构/标签按 `references/format.md`（`<Subject N>` / `<Picture N>` / 三核心字段 / `[Shot N]` 时间戳）；@ 名只出现在 `<Subject N>` 定义句里标注照片来源，正文其余位置一律官方语法
- **⛔ 时长一律整秒**：所有交付页面/清单里镜头时长与起止显示为整数秒（`Math.round`），行内格式 `第1集-01 · 10s · I2VA`

生成：把合并后的 `<剧名>-分镜.json` 喂给适配脚本，产出总控台版网页（正文官方语法 + @ 来源标注、一镜 @ 数统计与超 9 提醒、图片生成提示词折叠、每镜/每集/全集复制按钮）：

```bash
node {baseDir}/scripts/build-console.cjs <剧名>-分镜.json --art <剧名>-art.json --cast <剧名>-cast.json --outline <剧名>-outline.json --out <输出目录>
```

内容（镜头/台词/提示词正文/首帧锚定）与原生版完全一致，只换引用写法。两版都交付：用户贴 MiniMax 官方用原生版，贴总控台用 @ 版。

### Step 4.6 — 极简清单（⛔ 默认交付形态）

用户只要提示词不要报告时，用此步收尾。读 `<剧名>-cast.json` / `<剧名>-art.json` / `<剧名>-分镜.json`，一键生成单页清单：

```bash
node {baseDir}/scripts/build-min.cjs <剧名>-cast.json <剧名>-art.json <剧名>-分镜.json --out <输出目录>
```

产出 `<剧名>-提示词清单.html`，四区上下排：

- **人物出图提示词**：每行「名字 + 复制提示词」按钮（只取 `image.prompt`，不要 voice/sheet/引文）
- **场景出图提示词**：每行「场景名 + 复制」（变体标注复用关系）
- **道具出图提示词**：每行「道具名 + 复制」
- **分镜视频提示词**：每行「`第N集-XX · 整秒s · 模式` + 复制」
- 每区顶部「复制全部」；**时长一律整秒**（`Math.round`）

中间环节的报告网页（outline-report/script-report/art-report/report.html）用户不看就不生成、不交付。

### Step 5 — 汇报

一句话说清：几集几镜、全剧预估时长 vs 目标、模式分布、`H3分镜提示词.html` 路径；没过的门和没出的图明说。

---

## 与上游 skill 的接力

```
novel-characters → cast.json    （谁：角色资产）
novel-outline    → outline.json （什么：结构与分集）
novel-art        → art.json     （哪里 + 手里拿的：场景/光照/道具）
novel-script     → script.json  （戏：场次、节拍、台词）
novel-storyboard → 分镜.json + 分镜表.md + H3分镜提示词.html（拍：镜号/时长/提示词/批次单）
```

## 边界

- 不改剧本/大纲结构；不做角色/场景设定
- 提示词正文英文（H3 标准），对白 `<d>[Chinese]` 保留原文
- 时长是估算不是秒表，±15% 容差；平台单次生成 4–15 秒，短于 4 秒的镜生成 4 秒后剪辑
- 短剧建议竖屏 9:16（网页版页头注明）
- 图片生成提示词内嵌自 art/cast.json；设定图仍走 codex `$imagegen` 出图（可选）

## 自测

```bash
node {baseDir}/scripts/selftest.mjs
```

不调模型、不花额度，覆盖：时长折算、说话人映射、validate 击穿用例、render 网页版关键结构。

## 自带样例

`{baseDir}/examples/起点-分镜.json`：5 集 58 镜完整批次单（I2VA×12 / T2VA×36 / FL2VA×5 / L2VA×5，全剧 301.4s/300s），当质量基准与测试夹具。
