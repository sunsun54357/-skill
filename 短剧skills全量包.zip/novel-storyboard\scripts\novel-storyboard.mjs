﻿// novel-storyboard.mjs — 分镜层确定性工具（零依赖）
// 用法：
//   node novel-storyboard.mjs seed <script.json> --art <art.json> --outline <outline.json> [--eps 1-3]
//   node novel-storyboard.mjs validate <batch.json> --script <script.json> --art <art.json> --outline <outline.json>
//   node novel-storyboard.mjs merge <workdir> --out <分镜.json>
//   node novel-storyboard.mjs render <分镜.json> --art <art.json> --cast <cast.json> --outline <outline.json> --out <目录>
import fs from 'node:fs';
import path from 'node:path';
import { spawnSync } from 'node:child_process';
import { fileURLToPath, pathToFileURL } from 'node:url';

// ---------- 纯函数 ----------

export const ACTION_SECONDS = 2.5;
export const CHARS_PER_SECOND = 4.5;

// 首帧锚定检查：剥掉对齐句与开头风格句后，正文开头（前 200 字符）必须从首帧写起
export function isFirstFrameAnchored(prompt) {
  const p = String(prompt || '');
  let body = p
    .split('\n')
    .filter((l) => !/^(For the target video|How the reference pictures)/i.test(l.trim()))
    .join('\n')
    .trim();
  // 去掉 "integrated_multimodal_description: [Shot 1] " 前缀与开头风格句（如 Semi-realistic cinematic short-drama style, ... .）
  body = body.replace(/^integrated_multimodal_description:\s*\[Shot 1\]\s*/i, '');
  body = body.replace(/^(Semi-realistic cinematic short-drama style|Semi-realistic environment|Live-action[^.]*|2D-animated[^.]*|3D CG[^.]*|Cinematic[^.]*|claymation[^.]*|watercolor[^.]*|vintage film[^.]*)[^.]*\.\s*/i, '');
  const head = body.slice(0, 200);
  return /(opens on the|opens with|begins from|begins with|starts from|starts with|exact first frame|settles into)/i.test(head);
}

export function durLine(line) {
  return (line.replace(/\s/g, '').length) / CHARS_PER_SECOND;
}

export function beatSeconds(beat) {
  return beat.speaker ? durLine(beat.line) : ACTION_SECONDS;
}

// 按发声顺序排说话人映射（VO 不占号）
export function buildSpeakers(episode, outline) {
  const nameOf = (id) => {
    const c = (outline.characters || []).find((x) => x.id === id);
    return c ? c.name : id;
  };
  const seen = new Set();
  const map = [];
  for (const sc of episode.scenes || []) {
    for (const b of sc.flow || []) {
      if (b.speaker && b.speaker !== 'VO' && !seen.has(b.speaker)) {
        seen.add(b.speaker);
        map.push({ id: `S${map.length + 1}`, castId: b.speaker, name: nameOf(b.speaker) });
      }
    }
  }
  return map;
}

// ---------- seed ----------

export function seedEpisodes(script, art, outline, range) {
  const nameOf = (id) => {
    const c = (outline.characters || []).find((x) => x.id === id);
    return c ? c.name : id;
  };
  return script.episodes
    .filter((e) => range.includes(e.ep))
    .map((ep) => {
      const scenes = (ep.scenes || []).map((sc) => {
        const artScene = (art.scenes || []).find((s) => s.id === sc.sceneId);
        return {
          sceneId: sc.sceneId,
          name: artScene ? artScene.name : sc.sceneId,
          lighting: sc.lighting || '',
          characters: sc.characters || [],
          beats: (sc.flow || []).map((b, i) => ({
            idx: i,
            kind: b.speaker ? 'line' : 'action',
            speaker: b.speaker || null,
            text: b.line || null,
            seconds: +beatSeconds(b).toFixed(3),
          })),
        };
      });
      const sceneSeconds = {};
      let t = 0;
      for (const sc of scenes) {
        sceneSeconds[sc.sceneId] = {};
        for (const b of sc.beats) {
          sceneSeconds[sc.sceneId][b.idx] = t;
          t += b.seconds;
        }
      }
      return {
        ep: ep.ep,
        targetSeconds: ep.targetSeconds,
        totalSeconds: +t.toFixed(2),
        speakers: buildSpeakers(ep, outline).map((s) => ({ ...s, name: nameOf(s.castId) })),
        scenes,
        beatCumulative: sceneSeconds,
      };
    });
}

// ---------- validate ----------

export function validateBatch(batch, script, art, outline) {
  const issues = [];
  const eps = batch.episodes || [{ episode: batch.episode || 1, targetSeconds: batch.targetSeconds, shots: batch.shots, speakers: batch.speakers || [] }];
  for (const b of eps) {
    const ep = (script.episodes || []).find((e) => e.ep === b.episode || e.ep === b.ep);
    if (!ep) { issues.push(`ep${b.episode}: 剧本里没有这一集`); continue; }
    const shots = b.shots || [];
    const total = shots.reduce((s, sh) => s + (sh.durationSeconds || 0), 0);
    if (shots.length < 8 || shots.length > 15) issues.push(`ep${b.episode}: 镜头数 ${shots.length} 不在 [8,15]`);
    const target = ep.targetSeconds != null ? ep.targetSeconds : 60;
    if (!(total >= target * 0.85 && total <= target * 1.15)) issues.push(`ep${b.episode}: 总时长 ${total.toFixed(2)}s 不在目标 ${target}s ±15%`);
    let t = 0;
    for (const sh of shots) {
      if (Math.abs((sh.startSeconds || 0) - t) > 0.02) issues.push(`ep${b.episode} ${sh.shotId}: start=${sh.startSeconds} 应=${t.toFixed(3)}`);
      t += sh.durationSeconds || 0;
      if (Math.abs((sh.endSeconds || 0) - t) > 0.02) issues.push(`ep${b.episode} ${sh.shotId}: end=${sh.endSeconds} 应=${t.toFixed(3)}`);
      if ((sh.durationSeconds || 0) < 1.5) issues.push(`ep${b.episode} ${sh.shotId}: 时长过短`);
      const sc = (art.scenes || []).find((s) => s.id === sh.sceneId);
      if (!sc) issues.push(`ep${b.episode} ${sh.shotId}: 未知场景 ${sh.sceneId}`);
      else if (sh.lighting && !(sc.lighting || []).some((l) => l.state === sh.lighting))
        issues.push(`ep${b.episode} ${sh.shotId}: 光照「${sh.lighting}」未在 ${sh.sceneId} 登记`);
      for (const d of sh.dialogue || []) {
        if (d.speakerId && d.speakerId !== 'VO' && !(b.speakers || []).some((s) => s.id === d.speakerId))
          issues.push(`ep${b.episode} ${sh.shotId}: 说话人 ${d.speakerId} 未在 speakers 映射`);
        if (d.castId && !(outline.characters || []).some((c) => c.id === d.castId))
          issues.push(`ep${b.episode} ${sh.shotId}: castId ${d.castId} 不存在`);
      }
      // 提示词格式
      const p = sh.prompt || '';
      if (!p.includes('[Shot 1]')) issues.push(`ep${b.episode} ${sh.shotId}: 提示词缺 [Shot 1]`);
      const imgMode = sh.mode === 'I2VA' || sh.mode === 'FL2VA' || sh.mode === 'L2VA';
      const hasAlign = /aligns with the|is fully referenced/.test(p);
      if (imgMode && !hasAlign) issues.push(`ep${b.episode} ${sh.shotId}: ${sh.mode} 缺对齐句`);
      if (!imgMode && hasAlign) issues.push(`ep${b.episode} ${sh.shotId}: T2VA 不应有对齐句`);
      if (!sh.negativePrompt) issues.push(`ep${b.episode} ${sh.shotId}: 缺 negativePrompt`);
      if (!isFirstFrameAnchored(p)) issues.push(`ep${b.episode} ${sh.shotId}: 提示词正文未从首帧写起（缺 opens on / begins from / exact first frame 等首帧锚定句）`);
    }
    // 台词逐字覆盖
    const scriptLines = [];
    for (const sc of ep.scenes || []) for (const beat of sc.flow || []) if (beat.speaker) scriptLines.push(beat.line);
    const sheetLines = shots.flatMap((sh) => (sh.dialogue || []).map((d) => d.text));
    for (const l of scriptLines) if (!sheetLines.includes(l)) issues.push(`ep${b.episode}: 台词缺失「${l}」`);
    for (const l of sheetLines) if (!scriptLines.includes(l)) issues.push(`ep${b.episode}: 多余台词「${l}」`);
  }
  return issues;
}

// ---------- render：分镜表.md + H3 html ----------

// 每镜参考图槽位分配：锚点（Picture N）优先，再按 refs 排角色/场景/道具，去重、上限 8
// 返回 { slots, transform }：slots 为 ref_image_1..N 清单；transform 把 <Picture N>/<Subject N> 改写为 ref_image_N
export function assignRefSlots(sh, art, cast, outline) {
  const MAX = 8;
  const sceneById = (id) => (art.scenes || []).find((s) => s.id === id);
  const charById = (id) => {
    const c = (outline.characters || []).find((x) => x.id === id);
    if (!c) return null;
    const cc = (cast.characters || []).find((x) => x.name === c.name);
    return cc ? { name: c.name, image: cc.image } : null;
  };
  const propById = (id) => (art.props || []).find((p) => p.id === id);
  const localHits = (src) => {
    const hits = [];
    const re = /images\/([sc]\d+)-sheet\.png/gi;
    let m;
    while ((m = re.exec(src || ''))) hits.push(m[1].toUpperCase());
    return hits;
  };
  const assigned = new Set();
  const slots = [];
  const slotByRef = {};
  const add = (role, name, gen, sourceId) => {
    if (slots.length >= MAX || assigned.has(sourceId)) return null;
    assigned.add(sourceId);
    const refId = `ref_image_${slots.length + 1}`;
    slots.push({ refId, role, name, gen, sourceId });
    return refId;
  };
  // 1) 图像模式锚点 → 最前槽位
  const hits = localHits(sh.firstFrameSource);
  if (sh.mode === 'I2VA') {
    const id = hits[0];
    if (id) {
      const info = id.startsWith('S') ? sceneById(id) : charById(id);
      const r = add('首帧', `${(info || {}).name || id}设定图`, (info || {}).image?.prompt || null, id);
      if (r) slotByRef.P1 = r;
    }
  } else if (sh.mode === 'L2VA') {
    const id = hits[0];
    const r = add('末帧', id ? `${(sceneById(id) || {}).name || id}设定图` : '（建议：本场场景主视角图）',
      id ? (sceneById(id) || {}).image?.prompt || null : (sceneById(sh.sceneId) || {}).image?.prompt || null, id || '__l2__');
    if (r) slotByRef.P1 = r;
  } else if (sh.mode === 'FL2VA') {
    const r1 = add('起帧（上一镜尾帧续接）', '—', null, '__fl1__');
    if (r1) slotByRef.P1 = r1;
    const id = hits[0];
    const r2 = add('末帧', id ? `${(sceneById(id) || {}).name || id}设定图` : '（建议：本场场景主视角图）',
      id ? (sceneById(id) || {}).image?.prompt || null : (sceneById(sh.sceneId) || {}).image?.prompt || null, id || '__fl2__');
    if (r2) slotByRef.P2 = r2;
  }
  // 2) refs 主体（角色/场景/道具）→ 后续槽位（去重：与锚点同一来源不再分配）
  for (const ref of sh.refs || []) {
    const m = ref.match(/<Subject (\d+)>\s*([^（]*?)（(?:art\.json|cast\.json)\s*([SCP]\d+)）/);
    if (!m) continue;
    const num = m[1];
    const srcId = m[3];
    let role = null, name = null, gen = null;
    if (srcId.startsWith('S')) {
      const sc = sceneById(srcId);
      if (!sc) continue;
      role = '场景参考'; name = `${sc.name}设定图`; gen = sc.image?.prompt || null;
    } else if (srcId.startsWith('C')) {
      const c = charById(srcId);
      if (!c) continue;
      role = '角色参考'; name = `${c.name}形象图`; gen = c.image?.prompt || null;
    } else {
      const p = propById(srcId);
      if (!p) continue;
      role = '道具参考'; name = `${p.name}设定图`; gen = p.image?.prompt || null;
    }
    const r = add(role, name, gen, srcId);
    if (r) slotByRef['S' + num] = r;
  }
  // 3) 提示词改写：<Picture N> / <Subject N> → ref_image_N（无槽位的主体标签直接移除）
  const transform = (prompt) => {
    let p = String(prompt || '');
    p = p.replace(/<Picture (\d+)>/g, (mm, n) => slotByRef['P' + n] || mm);
    p = p.replace(/<Subject (\d+)>,\s*/g, (mm, n) => (slotByRef['S' + n] ? `${slotByRef['S' + n]}, ` : ''));
    p = p.replace(/<Subject (\d+)>(\s*)/g, (mm, n, ws) => (slotByRef['S' + n] ? `${slotByRef['S' + n]}${ws}` : ''));
    p = p.replace(/[ \t]{2,}/g, ' ');
    p = p.replace(/\s*,(\s*,)+/g, ',');
    return p.trim();
  };
  return { slots, transform };
}

// 续接参考图：把「上一镜成图尾帧 = 本镜首帧」追加为最后一个 ref_image 槽位，
// 并在提示词最前面按 H3 格式明确声明该图是首帧（is fully referenced + 续接说明）。
// FL2VA 的 ref_image_1 已是「起帧（上一镜尾帧续接）」，不重复追加，只挂尾帧图预览；无上一镜（每集第一镜）不追加。
export function applyContinuity(sh, prev, slots, prompt) {
  if (!prev) return { slots, prompt };
  const tailSrc = `images/${prev.shotId}-tail.png`;
  if (sh.mode === 'FL2VA') {
    const s = slots.map((x, i) => (i === 0 ? { ...x, src: tailSrc } : x));
    return { slots: s, prompt };
  }
  let p = prompt;
  // I2VA 原首帧声明（设定图）让位：改为设计参考，避免与续接首帧冲突
  if (sh.mode === 'I2VA') {
    p = p.replace(
      /For the target video, at 0\.00 seconds into the target video, ref_image_1 \(from \[Shot 1\]\) is fully referenced\./,
      'ref_image_1 is the design reference image for the opening scene and characters.'
    );
  }
  const refId = `ref_image_${slots.length + 1}`;
  const contSlot = { refId, role: '上一镜尾帧 = 本镜首帧（续接）', name: '上一镜成图末帧（生成后回填）', gen: null, continuity: true, src: tailSrc };
  p = `For the target video, at 0.00 seconds into the target video, ${refId} (from [Shot 1]) is fully referenced — this image is the last frame of the previous shot and is the exact first frame of this video. The video opens on this frame and continues the previous shot's action seamlessly.\n\n${p}`;
  return { slots: [...slots, contSlot], prompt: p };
}

export function renderMd(merged, art, cast, outline) {
  const epTotal = (ep) => (ep.totalSeconds != null ? ep.totalSeconds : ep.shots.reduce((s, sh) => s + (sh.durationSeconds || 0), 0));
  const lines = [];
  lines.push('# 分镜表');
  lines.push('');
  const total = merged.episodes.reduce((s, e) => s + epTotal(e), 0);
  const shots = merged.episodes.reduce((s, e) => s + e.shots.length, 0);
  lines.push(`> 镜头总数 **${shots}** ｜ 全剧预估 **${total.toFixed(1)}s** ｜ 模式：T2VA / I2VA / FL2VA / L2VA`);
  lines.push('');
  for (const ep of merged.episodes) {
    lines.push(`## 第 ${ep.episode} 集（${Math.round(epTotal(ep))}s / 目标 ${ep.targetSeconds}s ±15%）`);
    lines.push('');
    lines.push(`**说话人**：${ep.speakers.map((s) => `${s.id}=${s.name}`).join('，')}`);
    lines.push('');
    lines.push('| 镜号 | 模式 | 场景 | 光照 | 时长 | 起止 | 首帧来源 | 台词 |');
    lines.push('| --- | --- | --- | --- | --- | --- | --- | --- |');
    for (const sh of ep.shots) {
      const dia = sh.dialogue.map((d) => `${d.name}：${d.text}`).join('；') || '—';
      lines.push(`| ${sh.shotId} | ${sh.mode} | ${sh.scene} | ${sh.lighting} | ${Math.round(sh.durationSeconds)}s | ${Math.round(sh.startSeconds)}–${Math.round(sh.endSeconds)}s | ${sh.firstFrameSource || '—'} | ${dia} |`);
    }
    lines.push('');
    lines.push('### 视频提示词');
    lines.push('');
    let prev = null;
    for (const sh of ep.shots) {
      lines.push(`#### ${sh.shotId}（${sh.mode} · ${Math.round(sh.durationSeconds)}s · ${sh.scene} ${sh.lighting}）`);
      let { slots, transform } = assignRefSlots(sh, art, cast, outline);
      let p = transform(sh.prompt);
      ({ slots, prompt: p } = applyContinuity(sh, prev, slots, p));
      prev = sh;
      if (slots.length) {
        lines.push('');
        lines.push(`**参考图**：${slots.map((s) => `${s.refId}（${s.role}·${s.name}）`).join('，')}`);
      }
      lines.push('');
      lines.push('```text');
      lines.push(p);
      lines.push('```');
      lines.push('');
    }
  }
  return lines.join('\n');
}

export function renderHtml(merged, art, cast, outline, script, outDir) {
  const sceneById = (id) => (art.scenes || []).find((s) => s.id === id);
  const charById = (id) => {
    const c = (outline.characters || []).find((x) => x.id === id);
    if (!c) return null;
    const cc = (cast.characters || []).find((x) => x.name === c.name);
    return cc ? { name: c.name, image: cc.image } : { name: c.name, image: null };
  };
  const propName = (id) => ((art.props || []).find((p) => p.id === id) || {}).name || id;
  // 每镜出现清单：场景 / 人物 / 道具 / 陈设（汇总 refs + 台词 + 剧本场次 + art 锚点）
  const appearance = (sh, ep) => {
    const items = [];
    let sceneLine = `${sh.scene || sh.sceneId}（${sh.sceneId}）· ${sh.lighting || '—'}`;
    const refScenes = (sh.refs || []).map((r) => (r.match(/art\.json (S\d+)/) || [])[1]).filter(Boolean).filter((id) => id !== sh.sceneId);
    if (refScenes.length) sceneLine += `　参考场景：${refScenes.join('、')}`;
    items.push({ k: '场景', v: sceneLine });
    const people = new Map();
    const addPeople = (name, id) => { if (!people.has(name)) people.set(name, new Set()); if (id) people.get(name).add(id); };
    for (const d of sh.dialogue || []) addPeople(d.speakerId === 'VO' ? '画外音' : (d.name || d.castId), d.speakerId);
    for (const r of sh.refs || []) {
      const m = r.match(/cast\.json (C\d+)/);
      if (m) { const c = (outline.characters || []).find((x) => x.id === m[1]); addPeople(c ? c.name : m[1], null); }
    }
    const sEp = ((script || {}).episodes || []).find((e) => e.ep === ep.episode || e.ep === ep.ep);
    const sSc = sEp && (sEp.scenes || []).find((s) => s.id === sh.sceneId);
    for (const cid of (sSc && sSc.characters) || []) {
      const c = (outline.characters || []).find((x) => x.id === cid);
      addPeople(c ? c.name : cid, null);
    }
    const peopleLine = [...people.entries()].map(([n, ids]) => ids.size ? `${n}（${[...ids].join(',')}）` : n).join('、') || '—';
    items.push({ k: '人物', v: peopleLine });
    const props = new Set();
    for (const r of sh.refs || []) { const m = r.match(/art\.json (P\d+)/); if (m) props.add(m[1]); }
    for (const p of (sSc && sSc.props) || []) props.add(p);
    items.push({ k: '道具', v: [...props].map(propName).join('、') || '—' });
    const anchors = ((sceneById(sh.sceneId) || {}).anchors || []).map((a) => a.name);
    items.push({ k: '陈设', v: anchors.length ? anchors.join('、') : '—' });
    return items;
  };
  const esc = (s) => String(s ?? '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
  let totalShots = 0, totalSec = 0;
  merged.episodes.forEach((ep) => { totalShots += ep.shots.length; totalSec += ep.totalSeconds != null ? ep.totalSeconds : ep.shots.reduce((s, sh) => s + (sh.durationSeconds || 0), 0); });
  const modeColors = { I2VA: '#4da3ff', T2VA: '#9aa5b1', FL2VA: '#ffb84d', L2VA: '#7bd88f' };
  let nav = '', sections = '';
  const preparedAll = [];
  for (const ep of merged.episodes) {
    const epTotal = ep.totalSeconds != null ? ep.totalSeconds : ep.shots.reduce((s, sh) => s + (sh.durationSeconds || 0), 0);
    nav += `<button class="ep-tab" data-ep="${ep.episode}">第 ${ep.episode} 集<br><small>${epTotal.toFixed(1)}s · ${ep.shots.length}镜</small></button>`;
    // 预计算每镜最终槽位与提示词（含续接参考图）
    const prepared = [];
    let prev = null;
    for (const sh of ep.shots) {
      let { slots, transform } = assignRefSlots(sh, art, cast, outline);
      let p = transform(sh.prompt);
      ({ slots, prompt: p } = applyContinuity(sh, prev, slots, p));
      prepared.push({ sh, slots, prompt: p });
      prev = sh;
    }
    preparedAll.push({ ep, prepared });
    let cards = '';
    for (const { sh, slots, prompt: tp } of prepared) {
      let imgHtml = '';
      for (const s of slots) {
        const preview = s.src && outDir && fs.existsSync(path.join(outDir, s.src)) ? s.src : null;
        imgHtml += `<div class="img-row"><span class="img-tag">${esc(s.refId)}</span><span class="img-role">${esc(s.role)}</span><span class="img-name">${esc(s.name)}</span>`;
        if (preview) imgHtml += `<span class="img-hint">（已提取：${esc(s.src)}）</span><img class="tail-preview" src="${esc(preview)}" alt="${esc(s.refId)}">`;
        else if (s.continuity) imgHtml += `<span class="img-hint">（无需生成：取上一镜成图末帧，自动提取）</span>`;
        else if (s.gen) imgHtml += `<details class="img-gen"><summary>图片生成提示词（${esc(s.name)}，可复制去千问/即梦出图）</summary><pre>${esc(s.gen)}</pre><button class="btn copy" data-copy="${esc(s.gen)}">复制图片提示词</button></details>`;
        imgHtml += `</div>`;
      }
      if (!slots.length) imgHtml = `<div class="img-row none">纯文本生成 · 无需图片</div>`;
      const dia = sh.dialogue.map((d) => `${d.name}：${d.text}`).join('<br>');
      const appHtml = appearance(sh, ep).map((a) => `<div class="cast-line"><span class="cast-k">${esc(a.k)}</span><span class="cast-v">${esc(a.v)}</span></div>`).join('');
      const anchorBadge = isFirstFrameAnchored(sh.prompt)
        ? `<span class="badge anchor ok">首帧锚定 ✓</span>`
        : `<span class="badge anchor bad">未锚定 ✗</span>`;
      cards += `<div class="card" id="${esc(sh.shotId)}"><div class="card-head"><span class="badge shot">${esc(sh.shotId)}</span><span class="badge mode" style="background:${modeColors[sh.mode] || '#666'}">${esc(sh.mode)}</span>${anchorBadge}<span class="scene">${esc(sh.scene)} · ${esc(sh.lighting)}</span><span class="dur">${Math.round(sh.durationSeconds)}s</span><span class="time">${Math.round(sh.startSeconds)}–${Math.round(sh.endSeconds)}s</span><button class="btn copy main" data-copy="${esc(tp)}">一键复制提示词</button></div><div class="cast-box">${appHtml}</div><div class="img-box">${imgHtml}</div>${dia ? `<div class="dialogue">🎙 ${dia}</div>` : ''}<details class="prompt-box"><summary>内容（MiniMax H3 格式，图片用 ref_image_N 引用）</summary><pre>${esc(tp)}</pre></details><details class="neg-box"><summary>负面词</summary><pre>${esc(sh.negativePrompt)}</pre><button class="btn copy" data-copy="${esc(sh.negativePrompt)}">复制负面词</button></details></div>`;
    }
    const epCopy = prepared.map(({ sh, prompt }) => `【${sh.shotId}】${sh.mode} · ${Math.round(sh.durationSeconds)}s\n${prompt}`).join('\n\n');
    sections += `<section class="ep-section" id="ep-${ep.episode}" data-ep="${ep.episode}"><h2>第 ${ep.episode} 集（${Math.round(epTotal)}s / 目标 ${ep.targetSeconds}s）</h2><div class="ep-actions"><span class="speakers">说话人：${ep.speakers.map((s) => `${s.id}=${s.name}`).join('，')}</span><button class="btn copy" data-copy="${esc(epCopy)}">复制本集全部提示词</button></div>${cards}</section>`;
  }
  const allPrompts = preparedAll.map(({ ep, prepared }) => `===== 第 ${ep.episode} 集 =====\n` + prepared.map(({ sh, prompt }) => `【${sh.shotId}】${sh.mode} · ${Math.round(sh.durationSeconds)}s\n${prompt}`).join('\n\n')).join('\n\n');
  return `<!DOCTYPE html>
<html lang="zh">
<head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>${esc(merged.source)} · MiniMax H3 分镜提示词</title>
<style>
:root{--bg:#0f1216;--card:#171c23;--card2:#1d242e;--line:#2a333f;--text:#e8edf2;--dim:#8b96a5;--accent:#4da3ff}*{box-sizing:border-box;margin:0;padding:0}
body{background:var(--bg);color:var(--text);font:14px/1.6 "Microsoft YaHei","PingFang SC",sans-serif;padding:24px}
header{max-width:1080px;margin:0 auto 20px}h1{font-size:24px;letter-spacing:1px}
.stats{color:var(--dim);margin:8px 0 4px}.note{color:var(--dim);font-size:12px;margin-top:6px}
.toolbar{display:flex;gap:10px;margin-top:12px;flex-wrap:wrap}
.ep-tabs{display:flex;gap:8px;flex-wrap:wrap;max-width:1080px;margin:0 auto 16px}
.ep-tab{background:var(--card2);color:var(--text);border:1px solid var(--line);border-radius:8px;padding:8px 14px;cursor:pointer;font-size:13px}
.ep-tab.active{background:var(--accent);color:#0b0e12;border-color:var(--accent)}
.ep-tab small{display:block;color:var(--dim);font-size:11px}.ep-tab.active small{color:#0b0e12}
.ep-section{max-width:1080px;margin:0 auto 32px}.ep-section h2{font-size:18px;margin-bottom:10px;border-bottom:1px solid var(--line);padding-bottom:8px}
.ep-actions{display:flex;justify-content:space-between;align-items:center;margin-bottom:12px;gap:10px;flex-wrap:wrap}
.speakers{color:var(--dim);font-size:12px}
.card{background:var(--card);border:1px solid var(--line);border-radius:10px;margin-bottom:14px;overflow:hidden}
.card-head{display:flex;align-items:center;gap:10px;padding:10px 14px;border-bottom:1px solid var(--line);flex-wrap:wrap}
.badge{border-radius:5px;padding:2px 8px;font-size:12px;font-weight:600}.badge.shot{background:#2c3747;color:var(--accent);font-family:Consolas,monospace}.badge.mode{color:#0b0e12}
.badge.anchor.ok{background:#123c28;color:#7bd88f}.badge.anchor.bad{background:#3c1a1a;color:#ff7b7b}
.scene{font-size:13px}.dur{font-size:16px;font-weight:700;color:var(--accent)}.time{color:var(--dim);font-size:12px;font-family:Consolas,monospace}
.btn{background:var(--accent);color:#0b0e12;border:none;border-radius:6px;padding:6px 12px;cursor:pointer;font-size:12px;font-weight:600}
.btn.copy{background:#2c3747;color:var(--accent);border:1px solid #3a4a5e}.btn.copy:hover{background:#3a4a5e}.btn.main{margin-left:auto}
.img-box{padding:10px 14px;border-bottom:1px solid var(--line);background:var(--card2)}
.img-row{display:flex;align-items:center;gap:8px;font-size:13px;flex-wrap:wrap}.img-row.none{color:var(--dim);font-style:italic}
.img-tag{background:#3d2f1a;color:#ffb84d;border-radius:4px;padding:1px 6px;font-family:Consolas,monospace;font-size:12px}
.img-role{color:#7bd88f;font-size:12px}.img-name{color:var(--text)}
.img-hint{color:#8b96a5;font-size:11px;font-style:italic}
.tail-preview{max-width:150px;border:1px solid var(--line);border-radius:6px;margin-top:4px;display:block}
.img-gen{margin-top:6px;font-size:12px}.img-gen summary{color:var(--accent);cursor:pointer}
.img-gen pre,.prompt-box pre,.neg-box pre{background:#0b0e12;border:1px solid var(--line);border-radius:6px;padding:10px;white-space:pre-wrap;word-break:break-word;font-family:Consolas,"Courier New",monospace;font-size:12px;color:#cdd6e0;margin:6px 0}
.dialogue{padding:6px 14px;font-size:13px;color:#ffd479}
.cast-box{padding:8px 14px;border-bottom:1px solid var(--line);background:#141a21;display:flex;flex-direction:column;gap:4px}
.cast-line{display:flex;gap:8px;font-size:13px;flex-wrap:wrap}
.cast-k{background:#2c3747;color:var(--accent);border-radius:4px;padding:0 6px;font-size:11px;font-weight:600;line-height:20px;flex-shrink:0}
.cast-v{color:#c8d2dc}
.prompt-box,.neg-box{padding:0 14px 10px}.prompt-box summary,.neg-box summary{color:var(--accent);cursor:pointer;font-size:12px;padding-top:6px}
#toast{position:fixed;bottom:24px;left:50%;transform:translateX(-50%);background:var(--accent);color:#0b0e12;padding:8px 18px;border-radius:8px;font-weight:600;opacity:0;transition:opacity .25s;pointer-events:none}#toast.show{opacity:1}
@media(max-width:720px){.btn.main{margin-left:0}}
</style></head>
<body>
<header><h1>🎬 ${esc(merged.source)} · MiniMax H3 分镜提示词</h1><div class="stats">${merged.episodes.length} 集 × ${merged.episodes[0]?.targetSeconds || 60} 秒 · 共 <b>${totalShots}</b> 镜 · 全剧预估 ${totalSec.toFixed(1)}s · 模式：I2VA / T2VA / FL2VA / L2VA（H3 标准格式）</div><div class="note">使用说明：每镜卡片含「几秒 / 照片 / 内容」——照片按 <b>ref_image_1 ~ ref_image_8</b> 排好槽位（首帧/末帧/角色/场景/道具参考图），先按各槽位的「图片生成提示词」出图（千问/即梦均可），上传到 MiniMax H3 后按槽位顺序对应；「内容」里的图片引用已全部写成 <b>ref_image_N</b>，直接粘贴即可。每个非首镜的最末槽位是 <b>续接参考图（上一镜尾帧 = 本镜首帧）</b>——生成上一镜后取它的成图末帧上传，提示词已按 H3 格式明确声明它是本镜首帧（<i>is fully referenced ... exact first frame</i>），保证镜头无缝衔接。**提示词按「首帧锚定」写作**：正文第一句从首帧可见状态开始（摄像机位/站位/姿势/场景状态），动作从首帧延续；每镜有「首帧锚定 ✓/✗」徽章，✗ 说明正文没从首帧写起。竖屏 9:16（短剧标准）；平台单次生成 4–15s，低于 4s 的镜生成 4s 后剪辑。一镜最多 8 张参考图，超出部分以文字描述为准。</div><div class="toolbar"><button class="btn copy" data-copy="${esc(allPrompts)}">复制全集提示词（${totalShots} 镜）</button></div></header>
<nav class="ep-tabs">${nav}</nav>
${sections}
<div id="toast">已复制到剪贴板 ✓</div>
<script>
(function(){var t=document.getElementById('toast');function show(){t.classList.add('show');setTimeout(function(){t.classList.remove('show')},1400)}
function copy(text){if(navigator.clipboard&&window.isSecureContext){navigator.clipboard.writeText(text).then(show,function(){fb(text)})}else{fb(text)}}
function fb(text){var a=document.createElement('textarea');a.value=text;a.style.position='fixed';a.style.opacity='0';document.body.appendChild(a);a.select();try{document.execCommand('copy');show()}catch(e){alert('复制失败，请手动选择复制')}document.body.removeChild(a)}
document.addEventListener('click',function(e){var b=e.target.closest('.copy[data-copy]');if(b)copy(b.getAttribute('data-copy'));
var tab=e.target.closest('.ep-tab');if(tab){document.querySelectorAll('.ep-tab').forEach(function(x){x.classList.remove('active')});tab.classList.add('active');var ep=tab.getAttribute('data-ep');document.querySelectorAll('.ep-section').forEach(function(s){s.style.display=s.getAttribute('data-ep')===ep?'block':'none'})}});
var first=document.querySelector('.ep-tab');if(first)first.click();})();
</script>
</body></html>`;
}

// ---------- CLI ----------

function readJson(p, label) {
  try { return JSON.parse(fs.readFileSync(p, 'utf8')); }
  catch (e) { console.error(`✗ 读 ${label || p} 失败：${e.message}`); process.exit(1); }
}

function parseArgs(argv) {
  const a = {};
  const positional = [];
  for (let i = 0; i < argv.length; i++) {
    const x = argv[i];
    if (x.startsWith('--')) { a[x.slice(2)] = argv[++i]; }
    else positional.push(x);
  }
  a._ = positional;
  return a;
}

function main(argv) {
  const cmd = argv[0];
  const a = parseArgs(argv.slice(1));
  if (cmd === 'seed') {
    const script = readJson(a._[0], 'script.json');
    const art = readJson(a.art, 'art.json');
    const outline = readJson(a.outline, 'outline.json');
    const range = (a.eps || '').split('-').map(Number);
    const from = range[0] || 1, to = range[1] || script.episodes.length;
    const eps = Array.from({ length: to - from + 1 }, (_, i) => from + i);
    console.log(JSON.stringify({ source: script.source, style: a.style || 'realistic', episodes: seedEpisodes(script, art, outline, eps) }, null, 2));
  } else if (cmd === 'validate') {
    const batch = readJson(a._[0], 'batch.json');
    const script = readJson(a.script, 'script.json');
    const art = readJson(a.art, 'art.json');
    const outline = readJson(a.outline, 'outline.json');
    const issues = validateBatch(batch, script, art, outline);
    if (issues.length) { console.error(`✗ ${issues.length} 处违规：`); issues.forEach((i) => console.error('  ' + i)); process.exit(1); }
    const n = batch.episodes ? batch.episodes.reduce((s, e) => s + e.shots.length, 0) : batch.shots.length;
    console.log(`✓ 通过校验（${n} 镜）`);
  } else if (cmd === 'merge') {
    const dir = a._[0];
    const files = fs.readdirSync(dir).filter((f) => /^ep\d+\.json$/.test(f)).sort((x, y) => parseInt(x.match(/\d+/)) - parseInt(y.match(/\d+/)));
    if (!files.length) { console.error('✗ workdir 里没有 epN.json'); process.exit(1); }
    // 兼容两种单集格式：顶层 episodes 包装（episodes[0]）或顶层 shots 单集批
    const eps = files.map((f) => {
      const j = readJson(path.join(dir, f), f);
      return (j.episodes && j.episodes[0]) || j;
    });
    const merged = { source: a.source || eps[0]?.source || '剧名', style: a.style || 'realistic', episodes: eps };
    console.log(JSON.stringify(merged, null, 2));
    if (a.out) fs.writeFileSync(a.out, JSON.stringify(merged, null, 2), 'utf8');
    console.log(`已合并 ${eps.length} 集 → ${a.out}`);
  } else if (cmd === 'extract') {
    // 自动截尾帧：视频按 <镜号>.mp4 命名放入目录，提取每支视频最后一帧到 images/<镜号>-tail.png
    const dir = a._[0];
    if (!dir) { console.error('用法：extract <视频目录> --out <images目录> [--python python]'); process.exit(1); }
    const outDir = a.out || path.join(dir, '..', 'images');
    fs.mkdirSync(outDir, { recursive: true });
    const py = a.python || 'python';
    const pyScript = path.join(path.dirname(fileURLToPath(import.meta.url)), 'extract_tail.py');
    const files = fs.readdirSync(dir).filter((f) => /\.(mp4|mov|webm|mkv)$/i.test(f));
    if (!files.length) { console.error(`✗ ${dir} 里没有视频文件（按 <镜号>.mp4 命名，如 E1S01-02.mp4）`); process.exit(1); }
    let done = 0;
    for (const f of files) {
      const base = f.replace(/\.[^.]+$/, '');
      const dst = path.join(outDir, `${base}-tail.png`);
      if (fs.existsSync(dst)) { console.log(`∃ ${dst}（已存在，跳过）`); done++; continue; }
      const r = spawnSync(py, [pyScript, path.join(dir, f), dst], { stdio: 'inherit' });
      if (r.status === 0) { console.log(`✓ ${dst}`); done++; }
      else console.error(`✗ ${f} 截帧失败`);
    }
    console.log(`完成：${done}/${files.length} 支视频尾帧已提取到 ${outDir}`);
  } else if (cmd === 'render') {
    const merged = readJson(a._[0], '分镜.json');
    const art = readJson(a.art, 'art.json');
    const cast = readJson(a.cast, 'cast.json');
    const outline = readJson(a.outline, 'outline.json');
    const script = readJson(a.script, 'script.json');
    const outDir = a.out || '.';
    fs.mkdirSync(outDir, { recursive: true });
    const base = `${outDir}/${merged.source}`;
    fs.writeFileSync(`${base}-分镜表.md`, renderMd(merged, art, cast, outline), 'utf8');
    fs.writeFileSync(`${base}-H3分镜提示词.html`, renderHtml(merged, art, cast, outline, script, outDir), 'utf8');
    console.log(`已生成 ${base}-分镜表.md 与 ${base}-H3分镜提示词.html`);
  } else {
    console.error(`用法：\n  seed <script.json> --art --outline [--eps 1-3]\n  validate <batch.json> --script --art --outline\n  merge <workdir> --out <分镜.json>\n  extract <视频目录> --out <images目录> [--python python]\n  render <分镜.json> --art --cast --outline --script --out <目录>`);
    process.exit(1);
  }
}

const isMain = process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href;
if (isMain) main(process.argv.slice(2));
