---
name: beauty-video
version: 1.0.0
description: |
  给女性形象/美女主题视频出 MiniMax-H3 视频提示词：时尚大片、美妆展示、人像写真、
  氛围感镜头、古风/汉服、街拍、舞蹈、海边度假、都市夜景等方向，覆盖 T2VA / I2VA /
  FL2VA / L2VA / 全参考六段式全部模式。产出可直接粘贴到 MiniMax（海螺）的 H3 格式
  提示词（integrated_multimodal_description / overall_soundscape / non_diegetic_music
  或六段式）。聚焦专业审美：电影感光影、运镜语言、服装妆造、氛围情绪、慢镜头节奏；
  内容保持高级感与得体，不输出低俗、擦边、性暗示内容。参考 H3 格式规范
  references/base-en.md 与 references/ref-en.md。
  Use when asked to 美女视频、时尚大片、美妆视频、人像写真、氛围感视频、古风美女、
  汉服视频、街拍视频、舞蹈视频、女性形象视频、beauty video、fashion video、
  portrait video、MiniMax H3 美女、海螺美女提示词。
---

# 美女 · MiniMax-H3 视频提示词生成器

给女性形象/美女主题视频出 MiniMax-H3 提示词：时尚大片、美妆、写真、氛围感、古风、街拍、舞蹈等。
**平台**：仅 MiniMax（海螺）。
**风格基调**：电影感、高级感、专业审美；内容得体，不低俗、不擦边。

---

## 0. 输入约定（⛔ 用户参考信息怎么用）

### 0.0 两层结构（⛔ 每次生成必守）

**提示词分两层：正文按 MiniMax 官方规则写；包装行给总控台看。**

```
时长：8秒                     ← 第 1 层：总控台包装行（它读时长、提交时过滤）

subject_definitions:          ← 第 2 层：MiniMax 官方正文（六段式 / 三核心 / 对齐句）
<Subject 1> is the person in photo @1, ...
<Subject 2> is the background in photo @背景自拍镜子, ...
summary: ...
retention_analysis: ...
detailed_description: ...
overall_soundscape: ...
non_diegetic_music: ...
```

**第 1 层（总控台包装，写最顶部一行）**：
- `时长：N秒`：N 取整数秒，中文全角冒号。总控台读取时长、提交时**自动过滤**，不进模型。
- 正文里引用照片的来源写成 **`@照片库名`**（如 `@1`、`@背景自拍镜子`），总控台把第一个 @ 转 `ref_image_0`（主图）、依次往后，最多 9 个 @；提交前按 @ 名与照片库比对。
- 除此之外**不要**再加【本镜照片】等清单。

**第 2 层（MiniMax 官方正文，按 `references/base-en.md` / `ref-en.md` 写）**：
- 结构：全参考用六段式 `subject_definitions` / `summary` / `retention_analysis` / `detailed_description` / `overall_soundscape` / `non_diegetic_music`；无参考用三核心字段；首尾帧用对齐句。
- **引用标签 = 官方语法 `<Subject N>` / `<Picture N>` / `<Video N>` / `<Audio N>`**。`<Subject N>` 是"第 N 个可复用主体"（人物/背景/道具/服装等），`<Picture N>` 是具体帧锚点。规则：
  - `subject_definitions` 里给每个主体一行定义，标注照片来源用 **`@照片库名`**（`<Subject 1> is the person in photo @1`）——@ 是总控台层标记，提交时总控台转成 ref_image_N，不进模型正文语义。
  - `detailed_description` 里**主体首次出现处插入对应 `<Subject N>` 标签**（官方要求），之后可用文字（the woman）指代；不要整段不插标签，也不要全段堆标签。
  - 正文里不把 `@名字` 当正文标签用——@ 只出现在 `subject_definitions` / `summary` 的来源标注句。
- 正文各段英文；对白/歌词/画面文字保留原语言。
- 语言分工：包装行（`时长：N秒`、@来源标注）中文；MiniMax 正文英文。

### 0.1 参考图槽位（MiniMax H3 上传参考图命名 ref_image_N）

| 槽位 | 用途 | 状态 |
| --- | --- | --- |
| `ref_image_1` | **人物形象参考**（美女本人外观：长相/发型/服装） | 可选，有则 `<Subject 1>` |
| `ref_image_2` | **背景/场景参考**（环境：地点/氛围/陈设） | 用户指定，固定为背景 → `<Subject 2>` |
| `ref_image_3+` | 额外参考（服装单品/道具/光线参考等） | 按需 |

- **ref_image_2 就是背景**：只定义场景，不单独立 Picture（除非用户明确要首帧/尾帧锚点）
- 人物 + 背景都有 → 六段式全参考：`<Subject 1>` 人物、`<Subject 2>` 背景
- 只有背景 → `<Subject 2>` 背景 + 人物纯文字描述（或 T2VA）
- 只有人物 → `<Subject 1>` 人物 + 背景纯文字描述

### 0.2 用户文字参考信息（姿势 / 机位 / 其他）

用户可能给：**姿势**（站/坐/侧身/回眸/行走/舞蹈动作）、**机位**（俯拍/仰拍/平视/特写/远景）、
**光线、服装、情绪、道具、时长比例**等。这些信息**直接写进提示词**，优先级高于默认模板：

| 参考信息 | 写进哪里 |
| --- | --- |
| 姿势/动作 | `[Shot 1]` 起的主体动作描述 |
| 机位/景别 | 镜头语言（Motion type + 景别 + 角度） |
| 光线 | 光影氛围句 |
| 服装/妆造 | `<Subject 1>` 定义 + 各镜保持一致 |
| 情绪 | 动作表情描述 |
| 时长/比例 | 提示词首行硬声明 |

### 0.3 输出流程

1. 用户给：主题/方向 +（可选）ref_image_1 人物 + ref_image_2 背景 + 姿势机位等参考信息
2. 判定模式：有参考图 → 六段式；纯文字 → T2VA；用户指定首尾帧 → I2VA/FL2VA/L2VA
3. 出提示词 + 1-3 行操作提示（传哪几张参考图、时长比例、模式）
4. 用户可迭代：换姿势/机位/光线/服装，只改对应描述重出

---

## 1. 输出格式总纲

| 用户需求 | 模式 | 输出结构 |
| --- | --- | --- |
| 纯文本生成，无参考素材 | T2VA | 无对齐句，三核心字段 |
| 首帧图 → 向前发展 | I2VA | 首帧对齐句 + 三核心字段 |
| 首帧图 + 尾帧图 | FL2VA | 首尾帧对齐句 + 三核心字段 |
| 尾帧图 ← 前推收敛 | L2VA | 末帧对齐句 + 三核心字段 |
| 有参考素材（角色/服装/场景/风格） | Full-Reference Mode | 六段式 |

### 三核心字段（T2VA / I2VA / FL2VA / L2VA 共用）

```text
integrated_multimodal_description: [Shot 1] ...

overall_soundscape: ...

non_diegetic_music: ...
```

### 六段式（Full-Reference Mode）

```text
subject_definitions:
summary:
retention_analysis:
detailed_description:
overall_soundscape:
non_diegetic_music:
```

### 对齐句

- I2VA：`For the target video, at 0.00 seconds into the target video, <Picture 1> (from [Shot 1]) is fully referenced.`
- FL2VA：`How the reference pictures align with the target video — Picture 1 (from Shot 1) aligns with the 0.00-second mark of the target video; Picture 2 (from Shot N) aligns with the S.SS-second mark of the target video.`
- L2VA：`How the reference pictures align with the target video — <Picture 1> (from [Shot N]) aligns with the S.SS-second mark of the target video.`

详细规范以 `references/base-en.md` 与 `references/ref-en.md` 为准。

---

## 2. 内容方向库（按用户主题选，可组合）

| 方向 | 关键词/场景 | 氛围 |
| --- | --- | --- |
| 时尚大片 | 都市天台、极简摄影棚、霓虹街角、玻璃幕墙 | 高级、利落、未来感 |
| 美妆展示 | 梳妆台、日光窗边、镜前特写 | 精致、通透、微距质感 |
| 人像写真 | 逆光、花海、森林、天台黄昏 | 温柔、通透、胶片感 |
| 氛围感 | 风扬发丝、纱帘、烛光、雨夜窗边 | 朦胧、情绪、慢节奏 |
| 古风/汉服 | 园林、长廊、竹林、雪景、灯会 | 古典、飘逸、水墨意境 |
| 街拍 | 斑马线、咖啡店、地铁站、老城区 | 松弛、生活感、胶片颗粒 |
| 舞蹈 | 排练室、舞台、天台、光影墙 | 动感、力量、节奏卡点 |
| 海边度假 | 沙滩、海浪、日落、度假屋 | 自由、明亮、治愈 |
| 都市夜景 | 霓虹、车流、天台俯瞰、雨夜 | 迷离、电影感、蓝调 |

**每次输出注明本次方向**（如「时尚大片 · 都市天台 · 黄昏」）。

---

## 3. 固定规范（⛔ 每次生成必须遵守）

### 2.1 画风基线（默认电影感半写实）

- `Cinematic, film-like, shallow depth of field, natural skin texture, soft cinematic lighting`
- 胶片/颗粒质感可选：`35mm film grain, subtle halation, warm highlights`
- 动漫风可选：`2D anime style / 3D CG render / watercolor illustration`（用户要求时）

### 2.2 女性形象描述（⛔ 本 skill 的形象定义）

**本 skill 的"美女"形象定义（固定默认，除非用户另指定）**：

- **美女**：年轻女性，五官精致（清晰下颌线、明亮眼眸、挺秀鼻梁、饱满唇形），面容具有镜头吸引力
- **身材好**：身材高挑匀称，曲线柔美（腰臀比协调、线条紧致、健康有致），体态挺拔，气质加分
- **性感**：作为正当审美气质方向——可以是**清冷性感**（从容疏离、慵懒从容）、**明媚性感**（自信大方、笑容热烈）、**柔美性感**（曲线与动态的优雅展现），通过姿态、光影、服装线条、动作节奏来呈现

**描述维度（每次至少覆盖）**：

| 维度 | 示例 |
| --- | --- |
| 面容 | 精致五官、清透妆感、红唇/淡妆 |
| 身材 | 高挑匀称、曲线柔美、紧致线条（马甲线/腰线）、体态挺拔 |
| 气质 | 性感（清冷/明媚/柔美）、优雅、自信、飒爽 |
| 服装 | 贴合身形的剪裁（瑜伽服/连衣裙/礼服/泳装/运动装）、露肤度与美感平衡 |
| 姿态动作 | 回眸、撩发、侧身、伸展、起舞、凝视镜头、舒展腰线 |

**风格基调**：性感是**高级感的性感**——靠光影、姿态、节奏与服装线条呈现，**不是暴露堆砌**。

- 动作与情绪：回眸、撩发、侧脸、行走、起舞、凝视镜头、微笑、沉思、伸展、拉伸
- **禁止**：低俗、擦边、性暗示、刻意暴露、色情化表述；性感 ≠ 露骨，保持专业审美与得体边界

### 2.3 镜头语言（Motion type + Amplitude + Speed）

| 类型 | 用法 |
| --- | --- |
| Push In / Pull Out | 情绪推进：从全身推到面部特写 |
| Arc Shot | 环绕：展示服装/舞姿/发丝 |
| Tracking Shot | 跟拍：行走、奔跑、舞蹈 |
| Tilt Up / Tilt Down | 从鞋到脸（时尚登场）/ 从发梢到全身 |
| Pan Left / Right | 环境交代、裙摆扫过镜头 |
| Static Shot | 凝视镜头、情绪定格 |
| Slow Motion | 发丝扬起、裙摆飘动、水花 |

示例写法：
```
The camera arcs around her with medium amplitude at slow speed as her hair lifts in the breeze.
The camera pushes in with small amplitude at slow speed toward her face as she turns to the lens.
```

### 2.4 光影氛围（重中之重）

| 光影 | 效果 |
| --- | --- |
| Golden hour backlight | 发丝发光轮廓、暖调 |
| Rembrandt lighting | 经典人像、立体感 |
| Neon / practical lights | 夜景、赛博感 |
| Window light | 通透肤质、室内写真 |
| Candle / warm lamp | 氛围感、私密感 |
| Silhouette / rim light | 剪影、高级感 |

### 2.5 对白与声音

- 多数题材**无对白**，只有环境音 + 非剧情音乐（`non_diegetic_music`）
- 有对白时（如美妆口播、广告词）：用 `(S1)` + `<d>[语言] 原文</d>`，首次出现给出音色/语速/情绪
- 画外音：`says in an off-screen voiceover` + 紧跟 `while her lips remain completely closed`
- 歌词/口播保留原语言与标点

### 2.6 时长策略

| 时长 | 策略 |
| --- | --- |
| 4–8 秒 | 单动作/单氛围，1-2 镜，聚焦核心画面 |
| 9–12 秒 | 完整小场景，2-3 镜，时间戳分镜 |
| 13–15 秒 | 完整叙事/大片，3-4 镜，时间戳分镜 |
| >15 秒 | 分段拼接：首段正常生成 + 「视频延长」（每段 ≤15 秒） |

- 时间戳分镜法：`[Shot 1]`（无时间戳）→ `[Shot 2] At 00:03.500, ...`，切点严格递增
- 切镜：`the camera cuts to` / `the shot transitions to`
- 比例：默认 9:16（短视频）或按用户要求 16:9 / 1:1 / 2.35:1

### 2.7 参考素材（全参考模式）

- **ref_image_1 = 人物形象**：`<Subject 1>`（只定义形象，不单独立 Picture）
- **ref_image_2 = 背景/场景**：`<Subject 2>`（环境/氛围/陈设；用户指定为背景时固定此槽位）
- 首帧/尾帧/关键帧：`<Picture N>`（具体帧锚点，配对齐句，仅用户明确要求时用）
- 来源标注：`ref_image_N`（MiniMax H3 上传参考图命名）
- 用户的姿势/机位等文字参考：直接写进 `detailed_description` 对应镜头（见 0.2）
- **平台限制**：不支持上传写实真人脸部素材（会被拦截）；写实人像建议纯 T2VA 或使用 AI 生成的虚拟形象首帧

### 2.8 画面文字

- 画面可见文字（招牌/字幕/包装）：英文双引号包裹、逐字保留原文不翻译
- 默认无文字水印：`No text, letters, subtitles, or watermarks appear in any shot.`（用户要求字幕/歌词时再写）

---

## 4. 主题模板库（常用，直接套）

### 3.1 时尚大片（T2VA，13-15 秒）

`	ext
时长：13秒

```text
integrated_multimodal_description: [Shot 1] Cinematic fashion film, 35mm film grain, a woman in an elegant long coat walks through a sunlit city plaza, camera tracking her from the side with medium amplitude at normal speed, her coat hem sweeping, hair catching the golden-hour light. [Shot 2] At 00:05.000, the camera cuts to a low-angle shot from her heels tilting up to her face, she pauses and turns to the camera with a confident expression. [Shot 3] At 00:09.500, the camera arcs around her as she removes her sunglasses, wind lifting her hair, a slow-motion close-up of her profile against the warm sky.

overall_soundscape: Distant city ambience, soft wind, fabric swishing as the coat moves, and the gentle click of heels on pavement.

non_diegetic_music: A slow electronic pulse with a deep bass line at a moderate tempo, swelling slightly during the final arc shot and fading out.
```

### 3.2 美妆特写（I2VA，9-12 秒）

`	ext
时长：9秒

```text
For the target video, at 0.00 seconds into the target video, <Picture 1> (from [Shot 1]) is fully referenced.

integrated_multimodal_description: [Shot 1] Cinematic beauty film, soft window light, the woman shown in <Picture 1> sits at a sunlit vanity, preserving her face, makeup, hair, and the vanity layout; she dips a brush into a compact and applies blush with gentle strokes, eyes focused, a soft smile. The camera pushes in with small amplitude at slow speed toward her face. [Shot 2] At 00:05.000, the camera cuts to a macro close-up of the brush sweeping across her cheek, skin texture visible, then tilts up to her eyes as she blinks and looks into the mirror.

overall_soundscape: Quiet room ambience, the soft tap of the compact closing, and a gentle breath of satisfaction.

non_diegetic_music: Light piano notes at a slow tempo with soft strings underneath, gradually warming toward the end.
```

### 3.3 古风/汉服（T2VA，13-15 秒）

`	ext
时长：13秒

```text
integrated_multimodal_description: [Shot 1] Cinematic Chinese period film style, a woman in flowing hanfu stands in a misty bamboo grove, sleeves drifting, the camera pans right with small amplitude at slow speed as she turns and walks along the stone path. [Shot 2] At 00:05.000, the camera cuts to a close shot of her hand touching a bamboo leaf, dew dropping; she lifts her gaze, veil fluttering in the breeze. [Shot 3] At 00:09.500, the camera pulls out with large amplitude at slow speed, revealing her silhouette against the mist, sleeves and hair flowing as she walks away into the fog.

overall_soundscape: Wind through bamboo, distant birdsong, soft fabric rustling, and faint water sounds.

non_diegetic_music: Guzheng plucks at a slow tempo with sparse bamboo flute notes, volume swelling gently and receding into silence.
```

### 3.4 氛围感写真（L2VA，6 秒示例）

`	ext
时长：6秒

```text
How the reference pictures align with the target video — <Picture 1> (from [Shot 1]) aligns with the 6.00-second mark of the target video.

integrated_multimodal_description: [Shot 1] Cinematic portrait film, a close shot begins with a woman's silhouette against a bright window, her face in shadow. The camera pushes in with small amplitude at slow speed as she turns her head slowly toward the light; her features emerge softly from the shadow, hair strands catching the warm glow, until she settles into the exact expression, angle, and lighting established by <Picture 1> at the end of the shot.

overall_soundscape: Soft room tone with faint street noise outside, and the barely audible rustle of fabric as she turns.

non_diegetic_music: A single sustained cello note at a slow tempo with a soft piano chord fading in beneath it.
```

---

## 5. 全参考六段式模板（@人物照 + @背景照，总控台照片库命名）

> 总控台照片库按 @ 名上传照片，提示词里 `@名字` 是来源标注（提交时总控台转 ref_image_N）。模板里的 @1/@背景自拍镜子 是照片库名占位，按实际照片名替换。

```text
subject_definitions:
<Subject 1> is the person in photo @1, with [发型/发色/服装/气质描述]; this subject is used only to define the woman's appearance, which must stay identical in every shot.
<Subject 2> is the background in photo @背景自拍镜子, featuring [场景关键特征：地点/光线/陈设/氛围].

summary:
[reference generation] The target video is a [X]-second [比例] [方向] clip. <Subject 1> ... [一句话剧情/动作，融入用户给的姿势/机位] ... The reference image guides only the woman's appearance and the background; all actions and movements are newly generated.

retention_analysis:
<Subject 1> (appears in [Shot 1], [Shot 2], ...): fully_preserved - [发型/服装/气质特征] are retained in every shot.
<Subject 2> (appears in [Shot 1], [Shot 2], ...): fully_preserved - [背景关键特征：地点/光线/陈设] are retained.

detailed_description:
Cinematic film style with [光影/颗粒/色调]; [比例] composition is kept throughout.
[Shot 1] ...（背景 <Subject 2> 建立 + 人物 <Subject 1> 以用户指定姿势/机位入镜 → 动作延续）
[Shot 2] At 00:05.000, ...（机位/景别变化）
[Shot 3] At 00:09.500, ...（收尾/情绪镜头）
No text, letters, subtitles, or watermarks appear in any shot.

overall_soundscape:
[环境音 1-4 句，与背景 <Subject 2> 匹配]

non_diegetic_music:
[配器/速度/力度 1-3 句]
```

> 只有 ref_image_2（背景）时：`<Subject 2>` 背景 + 人物用文字描述；
> 只有 ref_image_1（人物）时：`<Subject 1>` 人物 + 背景用文字描述。

---

## 6. 交付格式

- 每次输出：**方向说明**（1 行）+ 完整可复制提示词（代码块，注明模式 T2VA/I2VA/FL2VA/L2VA/六段式）
- 多版本时：2-3 个风格版本供选（如 电影感 / 胶片颗粒 / 动漫风）
- 附 1-3 行操作提示（模式选择、参考图上传、时长比例、延长拼接）
- 用户可要求：换方向、换光影、换运镜、改时长、改风格、加/减对白、出多版本

---

## 7. 内容边界（⛔）

- **形象默认**：美女、身材好、性感（见 2.2）——这是本 skill 的正当审美方向（时尚/健身/写真/舞蹈/瑜伽语境）
- **性感的方式**：高级感的性感——光影、姿态、服装线条、动作节奏呈现；**禁止**低俗、擦边、性暗示、刻意暴露、色情化表述
- 写实人像注意平台限制（写实真人脸部素材不可上传），推荐纯 T2VA 或 AI 虚拟形象首帧
- 涉及商业/明星形象时，提示用户确认肖像权与授权
