# 幼儿英语 · 样例：apple 三段版（方案 B）

> 首个基准样例。单词 **apple**，三场景连续故事（客厅 → 苹果园 → 树荫 picnic），
> 每段 10 秒、9:16、5 句 Level1/2 简单英语、慢语速、方案 B（独立生成 + 剪辑拼接）。
> 衔接点：段 1 结尾（追小狗出门）= 段 2 开头；段 2 结尾（苹果举到嘴边正要咬）= 段 3 开头。

## 句子清单（全部 Level1/2）

| 段 | 句子 | 级别 |
|----|------|------|
| 1 客厅 | `Look! An apple!` | L1 |
| 1 客厅 | `What is that? It is an apple!` + `It is red.` | L1 |
| 1 客厅 | `Apple! A-P-P-L-E. Apple!`（拼读）+ 齐声 `Apple! Apple!` | L1 |
| 1 客厅 | `Where is it going?`（悬念钩子） | L1 |
| 2 果园 | `Apples grow on trees!` | L2 |
| 2 果园 | `This apple is big and red.` + `I can pick an apple!` | L2 |
| 2 果园 | 齐声 `Apple! Apple!` | L1 |
| 2 果园 | `What does it taste like?`（悬念钩子） | L2 |
| 3 picnic | `Mmm! Yummy!` | L1 |
| 3 picnic | `This is an apple.` + `It is red and sweet.` | L1/L2 |
| 3 picnic | `I like apples!` + `Do you like apples?` | L1/L2 |
| 3 picnic | 齐声 `Apple! Apple!` + `Bye-bye!`（收尾） | L1 |

---

# 📹 第一段 · 10 秒 · 客厅（方案 B）

```text
subject_definitions:
<Subject 1> is the cute chibi child in the uploaded reference image ref_image_1, with a round soft face, warm light brown irises, tiny gentle pupils, soft rounded cartoon eyes, simple stubby rounded three-finger hands, and a cozy outfit; this subject is used only to define the child's appearance, which must stay identical in every shot.

summary:
[reference generation] The target video is the first segment, exactly 10.00 seconds long, vertical 9:16, a children's English-learning clip in a warm storybook style with continuous motion throughout. <Subject 1>, the chibi child defined by the reference image, is surprised by a red apple rolling off the coffee table, names it, and spells it aloud, while a puppy snatches the apple and runs toward the door as a hook for the next segment. All English dialogue is made of very simple short sentences with basic words, spoken at a slow, gentle pace with clear enunciation and brief pauses, so young children can repeat each line easily. The reference image guides only the child's appearance; the living room, the puppy, and all actions are newly generated.

retention_analysis:
<Subject 1> (appears in [Shot 1], [Shot 2], [Shot 3], [Shot 4]): fully_preserved - the child's round face, light brown irises, tiny pupils, soft cartoon eyes, three-finger stubby hands, outfit, and chibi proportions are retained in every shot.

detailed_description:
Vertical 9:16, 24fps, exactly 10.00 seconds. 2D children's storybook illustration style with colored pencil texture, grainy paper texture, crayon drawing details, soft hand-drawn outlines, a warm pastel color palette, soft rounded shapes, and bright warm daylight streaming through a living-room window; every shot stays in continuous motion, never holding a static pose. All spoken English uses simple short words and is delivered at a slow, gentle pace with clear enunciation and a brief pause after each sentence, suitable for children to repeat.
[Shot 1] A medium shot frames a cozy sunny living room with a low wooden coffee table holding a small white plate of three glossy red apples. A small fluffy puppy barks "Woof!" once, and one red apple tips and rolls off the table, bouncing across the wooden floor with a soft clatter. <Subject 1>, the chibi child from the reference image, jumps down from the sofa, eyes wide, and with a warm, gentle, slow-paced voice (S1) says the short line: <d>[English] Look! An apple!</d> The camera trucks left with small amplitude at medium speed, following the rolling apple.
[Shot 2] At 00:02.500, the camera cuts to a close shot of <Subject 1> crouching down and scooping the apple up with both stubby hands, hugging it to the chest. The puppy waddles over, ears perked. The child speaks slowly and clearly (S1), pausing between sentences: <d>[English] What is that? It is an apple!</d> then adds softly, <d>[English] It is red.</d> The camera pushes in with small amplitude at slow speed toward the child's smiling face.
[Shot 3] At 00:05.000, the shot transitions to a close-up of <Subject 1> holding the apple up high with both hands, tilting it so its glossy skin catches the window light, while the puppy sits up and wags its tail. The child spells the word slowly, one letter at a time (S1): <d>[English] Apple! A-P-P-L-E. Apple!</d> while a chorus of cheerful off-screen children's voices (S2) echoes the simple word, <d>[English] Apple! Apple!</d> The puppy barks softly in excitement.
[Shot 4] At 00:07.500, the camera cuts to a medium shot: the puppy suddenly grabs the apple in its mouth, turns, and scampers toward the front door, its paws skidding on the floor. The door swings open a crack and golden sunlight floods in. <Subject 1> runs after the puppy and calls out in a lively but still slow, clear voice (S1): <d>[English] Where is it going?</d> The shot ends with the child silhouetted against the bright doorway, chasing the puppy outside, the apple still in the puppy's mouth. No text, letters, subtitles, or watermarks appear in any shot.

overall_soundscape:
Soft living-room ambience with faint birdsong from the open window. The apple clatters as it rolls and bounces off the table, the puppy barks and yips excitedly, its paws patter across the floor, and the front door creaks open.

non_diegetic_music:
Light ukulele strumming at a moderate tempo with bouncy woodblock percussion, the volume lifting slightly during the spelling chant and rising with playful anticipation as the puppy runs to the door.
```

---

# 📹 第二段 · 10 秒 · 苹果园（方案 B）

```text
subject_definitions:
<Subject 1> is the cute chibi child in the uploaded reference image ref_image_1, with a round soft face, warm light brown irises, tiny gentle pupils, soft rounded cartoon eyes, simple stubby rounded three-finger hands, and a cozy outfit; this subject is used only to define the child's appearance, which must stay identical in every shot.

summary:
[reference generation] The target video is the second segment, exactly 10.00 seconds long, vertical 9:16, generated independently and then spliced after the first segment in editing. <Subject 1>, the chibi child defined by the reference image, begins in the exact same state where the first segment ended — running out of the bright doorway chasing the puppy — then follows the puppy into a sunny apple orchard, discovers that apples grow on trees, picks a big red one, and raises it toward the mouth as a hook for the next segment. All English dialogue is made of very simple short sentences with basic words, spoken at a slow, gentle pace with clear enunciation and brief pauses, so young children can repeat each line easily. The opening motion, framing, bright daylight, and running pace are intentionally written to match the first segment's ending so the two clips cut together seamlessly.

retention_analysis:
<Subject 1> (appears in [Shot 1], [Shot 2], [Shot 3], [Shot 4]): fully_preserved - the child's round face, light brown irises, tiny pupils, soft cartoon eyes, three-finger stubby hands, outfit, and chibi proportions are retained in every shot.

detailed_description:
Vertical 9:16, 24fps, exactly 10.00 seconds. 2D children's storybook illustration style with colored pencil texture, grainy paper texture, crayon drawing details, soft hand-drawn outlines, a warm pastel color palette, soft rounded shapes, and bright golden sunlight in a lush green apple orchard with white clouds drifting; every shot stays in continuous motion, never holding a static pose. All spoken English uses simple short words and is delivered at a slow, gentle pace with clear enunciation and a brief pause after each sentence, suitable for children to repeat.
[Shot 1] The segment opens mid-action: <Subject 1>, the chibi child from the reference image, runs out of a bright doorway into a sunlit apple orchard, following a small fluffy puppy which drops a red apple on the grass and turns back with a happy "Woof!" The camera tracks the running child with small amplitude at medium speed, transitioning from the doorway to the open orchard.
[Shot 2] At 00:02.500, the camera cuts to a low-angle wide shot: the child stops and looks up, eyes widening in wonder at an apple tree heavy with glossy red apples, leaves rustling and one leaf drifting down. A small bird flits across the sky. The child with a warm, excited but slow, clear voice (S1) says: <d>[English] Apples grow on trees!</d> The camera tilts up with small amplitude at slow speed along the tree trunk.
[Shot 3] At 00:05.000, the shot transitions to a medium shot of <Subject 1> rising onto tiptoes, stretching both stubby arms up, and plucking a big red apple from a low branch with a soft pop. The child hugs it, beams, and speaks slowly and clearly (S1), pausing between sentences: <d>[English] This apple is big and red.</d> then <d>[English] I can pick an apple!</d> The puppy bounces excitedly around the child's feet while the off-screen children's chorus (S2) echoes the simple word, <d>[English] Apple! Apple!</d>
[Shot 4] At 00:07.500, the camera cuts to a close-up of <Subject 1> holding the apple with both hands and slowly raising it toward the mouth, eyes sparkling, while the puppy sits up on its hind legs, tilting its head, tongue out, waiting. The child pauses right at the moment before the first bite and says playfully in a slow, clear voice (S1): <d>[English] What does it taste like?</d> The camera pushes in with small amplitude at slow speed toward the shiny apple as the shot ends right before the bite. No text, letters, subtitles, or watermarks appear in any shot.

overall_soundscape:
Gentle orchard breeze rustles the leaves with distant birdsong and soft grass swishing underfoot. The apple pops softly as it is plucked, the puppy pants and yips happily, and one leaf rustles down past the camera.

non_diegetic_music:
Light ukulele strumming at a moderate tempo with bouncy woodblock percussion, matching the first segment's key and volume at the splice point, growing slightly more playful during the picking moment and easing into a curious, suspended note as the apple rises toward the mouth.
```

---

# 📹 第三段 · 10 秒 · 树荫 picnic（方案 B）

```text
subject_definitions:
<Subject 1> is the cute chibi child in the uploaded reference image ref_image_1, with a round soft face, warm light brown irises, tiny gentle pupils, soft rounded cartoon eyes, simple stubby rounded three-finger hands, and a cozy outfit; this subject is used only to define the child's appearance, which must stay identical in every shot.

summary:
[reference generation] The target video is the third segment, exactly 10.00 seconds long, vertical 9:16, generated independently and then spliced after the second segment in editing. <Subject 1>, the chibi child defined by the reference image, begins in the exact same state where the second segment ended — holding the red apple at the mouth, about to take the first bite — then bites the apple, tastes it, says simple sentences about it, shares the apple with the puppy, and waves goodbye as a warm ending to the whole story. All English dialogue is made of very simple short sentences with basic words, spoken at a slow, gentle pace with clear enunciation and brief pauses, so young children can repeat each line easily. The opening pose, framing, orchard light, and waiting puppy are intentionally written to match the second segment's ending so the two clips cut together seamlessly.

retention_analysis:
<Subject 1> (appears in [Shot 1], [Shot 2], [Shot 3], [Shot 4]): fully_preserved - the child's round face, light brown irises, tiny pupils, soft cartoon eyes, three-finger stubby hands, outfit, and chibi proportions are retained in every shot.

detailed_description:
Vertical 9:16, 24fps, exactly 10.00 seconds. 2D children's storybook illustration style with colored pencil texture, grainy paper texture, crayon drawing details, soft hand-drawn outlines, a warm pastel color palette, soft rounded shapes, and warm golden light dappling through apple-tree leaves onto a soft picnic blanket; every shot stays in continuous motion, never holding a static pose. All spoken English uses simple short words and is delivered at a slow, gentle pace with clear enunciation and a brief pause after each sentence, suitable for children to repeat.
[Shot 1] The segment opens exactly on the end state of the second segment: a close-up of <Subject 1>, the chibi child from the reference image, holding the red apple at the mouth in the same pose and framing where the previous segment ended. The camera holds for one beat, then the child bites down with a crisp crunch; juice sparkles fly around the mouth, the child's cheeks puff as it chews, and with a warm, happy, slow-paced voice (S1) it hums the short line: <d>[English] Mmm! Yummy!</d> A small fluffy puppy leans in, nose twitching.
[Shot 2] At 00:02.500, the camera cuts to a close shot of <Subject 1> chewing with a big smile, then swallowing and speaking slowly and clearly (S1), pausing between sentences: <d>[English] This is an apple.</d> then softly, <d>[English] It is red and sweet.</d> The puppy waddles over and sits right beside the child, sniffing the air. The camera trucks right with small amplitude at slow speed to frame them together.
[Shot 3] At 00:05.000, the shot transitions to a medium shot on the picnic blanket: <Subject 1> breaks the apple in half and offers one piece to the puppy, which licks it up happily with a wagging tail. The child looks at the camera and speaks slowly and clearly (S1), pausing between sentences: <d>[English] I like apples!</d> then <d>[English] Do you like apples?</d> The puppy barks "Woof! Woof!" as if saying yes, and the off-screen children's chorus (S2) echoes the simple word, <d>[English] Apple! Apple!</d>
[Shot 4] At 00:07.500, the camera cuts to a wider medium shot: the child and the puppy sit side by side on the picnic blanket, munching their apple pieces together, then the child waves a stubby hand at the camera with a sunny smile and says in a bright but slow, clear voice (S1): <d>[English] Bye-bye!</d> The puppy wags its tail next to the child as the warm golden light glows around them, ending the video on this cozy happy frame. No text, letters, subtitles, or watermarks appear in any shot.

overall_soundscape:
The orchard breeze and birdsong continue softly from the previous segment. A crisp crunch marks the first bite, followed by soft chewing, the puppy's happy lap and tail thump on the blanket, and the child's cheerful giggle.

non_diegetic_music:
Light ukulele strumming at a moderate tempo with bouncy woodblock percussion, matching the second segment's key and volume at the splice point, lifting into a warm, bright finale during the sharing moment and easing down to a soft, gentle ending.
```

---

## 使用备注

- 三段各自独立生成：都传 `ref_image_1` 角色参考（不勾首帧）、时长 10 秒、9:16。
- 生成顺序可乱，拼接按 1 → 2 → 3；剪映/PR 首尾相接，BGM 在切点对齐音量。
- 若模型把某段开头/结尾动作跑偏（如"正要咬"变成了别的动作），改对应段 [Shot 1] 的衔接描述再重出。
- 新单词套用本模板：换单词、换场景、换朋友动物、句子按 Level1/2 同难度改写即可。
