# 提取视频最后一帧（尾帧）为 PNG
# 用法：python extract_tail.py <video> <out.png>
# 依赖：opencv-python（cv2）。
# 注意：Windows 版 OpenCV 的 VideoCapture / imwrite 不支持中文（非 ASCII）路径，
# 因此自动把输入复制到 ASCII 临时目录处理，输出经临时 PNG 再移动到目标路径。
import sys
import os
import tempfile
import shutil
import cv2


def main():
    if len(sys.argv) != 3:
        print('用法：python extract_tail.py <video> <out.png>', file=sys.stderr)
        sys.exit(2)
    src, dst = sys.argv[1], sys.argv[2]

    # 输入：非 ASCII 路径 → 复制到临时 ASCII 文件
    staged_src = src
    tmp_src = None
    if not src.isascii():
        fd, tmp_src = tempfile.mkstemp(suffix=os.path.splitext(src)[1] or '.mp4')
        os.close(fd)
        shutil.copyfile(src, tmp_src)
        staged_src = tmp_src

    cap = cv2.VideoCapture(staged_src)
    if not cap.isOpened():
        if tmp_src:
            try: os.remove(tmp_src)
            except OSError: pass
        print(f'无法打开视频：{src}', file=sys.stderr)
        sys.exit(1)
    frame = None
    ok = True
    while ok:
        ok, f = cap.read()
        if ok:
            frame = f
    cap.release()
    if tmp_src:
        try: os.remove(tmp_src)
        except OSError: pass
    if frame is None:
        print(f'未读到任何帧：{src}', file=sys.stderr)
        sys.exit(1)

    # 输出：非 ASCII 路径 → 先写临时 ASCII PNG 再移动
    staged_dst = dst
    tmp_dst = None
    if not dst.isascii():
        fd, tmp_dst = tempfile.mkstemp(suffix='.png')
        os.close(fd)
        staged_dst = tmp_dst
    ok_w = cv2.imwrite(staged_dst, frame)
    if not ok_w:
        if tmp_dst:
            try: os.remove(tmp_dst)
            except OSError: pass
        print(f'写入失败：{dst}', file=sys.stderr)
        sys.exit(1)
    if tmp_dst:
        os.makedirs(os.path.dirname(dst), exist_ok=True)
        shutil.move(tmp_dst, dst)
    print(dst)


if __name__ == '__main__':
    main()
