# 短剧分镜

**分镜层 skill**：给 AI 短剧出镜号、单镜头时长、模式（T2VA / I2VA / FL2VA / L2VA）、H3 格式视频提示词、首帧来源与生成批次单，并交付**一键复制网页版**。

## 输入

四件套 JSON（缺一不可，缺哪个先跑对应 skill）：

| 输入 | 来源 |
| --- | --- |
| `script.json` | novel-script |
| `outline.json` | novel-outline（角色 C 编号） |
| `art.json` | novel-art（场景/光照/道具） |
| `cast.json` | novel-characters（角色形象提示词） |

## 产出

```
<输出目录>/
├── <剧名>-分镜.json             机器可读批次单
├── <剧名>-分镜表.md             可读分镜表 + 全部提示词
└── <剧名>-H3分镜提示词.html     ⛔ 一键复制网页版（几秒/图片/内容三要素）
```

## 用法

```bash
# 1. seed 骨架（确定性算时长/光照/说话人）
node scripts/novel-storyboard.mjs seed 剧名-script.json --art 剧名-art.json --outline 剧名-outline.json --eps 1-3 > work/seed.json

# 2. 逐集写分镜（模型工作，见 SKILL.md），产出 work/epN.json

# 3. 校验（必须通过）
node scripts/novel-storyboard.mjs validate work/ep1.json --script 剧名-script.json --art 剧名-art.json --outline 剧名-outline.json

# 4. 合并 + 渲染
node scripts/novel-storyboard.mjs merge work --out 剧名-分镜.json
node scripts/novel-storyboard.mjs render 剧名-分镜.json --art 剧名-art.json --cast 剧名-cast.json --outline 剧名-outline.json --script 剧名-script.json --out .

# 5. 视频生成后：自动截每支视频尾帧 → images/<镜号>-tail.png（网页版续接槽位自动显示预览）
#    视频按镜号命名放入 videos/（如 E1S01-02.mp4）；依赖 Python + opencv
node scripts/novel-storyboard.mjs extract videos/ --out images
```

## 自测

```bash
node scripts/selftest.mjs
```

不调模型、不花额度：时长折算、说话人映射、校验击穿用例、渲染结构。

## 参考

- `references/format.md`：H3 格式全表（灯光/摄像角度/镜头语言/对齐句/三核心字段/@引用映射）
- `examples/起点-分镜.json`：5 集 58 镜完整样例（质量基准）
