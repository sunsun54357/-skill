---
name: 幼儿英语
version: 1.0.0
description: |
  给幼儿英语学习视频出 MiniMax-H3 视频提示词：用户给一个英语单词（中英文均可），
  生成围绕该单词的小故事视频，内含 Level1/2 超简单英语句子（3-5 词短句）、慢语速、
  固定小孩角色 ref_image_1、随机室内/室外场景、随机朋友动物物品、钩子结构与无缝衔接。
  产出可直接粘贴到 MiniMax（海螺）的 H3 格式提示词（六段式全参考模式 / 三核心字段）。
  规则：单段最长 10 秒，故事放不下拆多段（方案 B 独立生成后剪辑拼接，衔接点写死）。
  参考 MiniMax H3 格式规范 references/base-en.md（T2VA/I2VA/FL2VA/L2VA）与
  references/ref-en.md（全参考六段式）。
  Use when asked to 幼儿英语视频、英语启蒙视频、单词视频提示词、kids English video prompt、
  学单词视频、MiniMax H3 幼儿英语、海螺幼儿英语。
---

# 幼儿英语 · MiniMax-H3 视频提示词生成器

给幼儿英语学习视频出 MiniMax-H3 提示词。用户给出一个英语单词，AI 围绕它编一个小故事视频，
内嵌 Level1/2 超简单英语句子（适合零基础幼儿跟读），慢语速，固定小孩角色，场景室内/室外随机。

**平台**：仅 MiniMax（海螺），不涉及即梦。
**角色参考图**：`ref_image_1` = 固定小孩形象（chibi 绘本风），只做角色形象参考，不做首帧。
**输出语言**：正文各段英文，对白用 `<d>[English] ...</d>`，画面无文字（`--no text` 风格）。

---

## 0. 输出格式总纲

| 用户需求 | 模式 | 输出结构 |
| --- | --- | --- |
| 纯文本生成，无参考素材 | T2VA | 无对齐句，三核心字段 |
| 首帧图 → 向前发展 | I2VA | 首帧对齐句 + 三核心字段 |
| 有参考素材，需标注来源与保留关系 | Full-Reference Mode | 六段式 |

**幼儿英语默认流程**：`ref_image_1` 作为角色形象参考（全参考六段式，`<Subject 1>`），
不用首帧；除非用户明确要求首帧/尾帧模式。

### 三核心字段（T2VA / I2VA 共用）

```text
integrated_multimodal_description: [Shot 1] ...

overall_soundscape: ...

non_diegetic_music: ...
```

### 六段式（Full-Reference Mode，幼儿英语默认）

```text
subject_definitions:
summary:
retention_analysis:
detailed_description:
overall_soundscape:
non_diegetic_music:
```

- `subject_definitions`：`<Subject 1>` 是 ref_image_1 中的小孩，每个参考标签一行。
- `summary`：以 `[reference generation]` 或 `[video continuation + reference generation]` 前缀开头。
- `retention_analysis`：可见内容标 `fully_preserved` / `partially_preserved` 等。
- `detailed_description`：350–500 英文词，逐镜描述，参考标签在首次出现处插入。
- 对齐句（I2VA）：`For the target video, at 0.00 seconds into the target video, <Picture 1> (from [Shot 1]) is fully referenced.`

详细规范以 `references/base-en.md` 与 `references/ref-en.md` 为准。

---

## 1. 固定项目规则（⛔ 每次生成必须遵守）

### 1.1 角色
- `ref_image_1` 恒为 `<Subject 1>`：可爱 chibi 小孩，圆脸、暖浅棕虹膜、细小瞳孔、
  圆润卡通眼、三根短粗手指、柔和可爱服装。
- 参考图**只定义角色形象**，不勾选"首帧"，不做首帧锚点。
- 每次可随机加入朋友/动物/物品（小狗、小猫、小兔、小鸟、松鼠、玩偶、球、篮子……）。

### 1.2 场景
- 室内/室外**随机**，与单词贴合：apple→果园/厨房，sun→公园/窗边，cat→家里/院子……
- 每次输出注明本次随机结果（如「室外苹果园 + 小松鼠」）。

### 1.3 画风基线（沿用户 ref 图风格）
2D children's storybook illustration style, colored pencil texture, grainy paper texture,
crayon drawing details, soft hand-drawn outlines, warm pastel color palette,
soft rounded cartoon eyes, tiny gentle pupils, warm light brown irises,
stubby rounded 3-finger hands, no text/letters/subtitles/watermarks in any shot.

### 1.4 时长与分段
- **单段最长 10 秒**，竖屏 9:16，24fps。
- 提示词内硬声明 `Vertical 9:16, 24fps, exactly 10.00 seconds`。
- 时间戳按 10 秒排布（4 镜示例：`00:02.500` / `00:05.000` / `00:07.500`）。
- 故事 10 秒内讲完 → 单段；放不下 → 拆多段（每段 10 秒，场景不同）。

### 1.5 多段衔接（方案 B 为默认）
- **方案 B（默认）**：各段独立生成（都传 ref_image_1 角色参考、都 10 秒），剪映/PR 首尾拼接。
  段与段之间：上一段结尾动作状态 = 下一段开头动作状态（如"正要咬"→"咬下去"），
  同姿势、同景别、同环境音；第二段起 summary 写"beginning in the exact same state where the previous segment ended"。
- **方案 A**（用户可选）：MiniMax「视频延长」续接，第二段起用
  `[video continuation + reference generation]` + `<Video 1>` 标签标注续接来源。

### 1.6 钩子与节奏
- 每段开头要有**钩子**（声音/动作/视觉：东西滚落、小狗叫、追跑、惊喜发现）。
- 非末段结尾留**悬念**（"苹果要去哪？""什么味道？"），末段温馨收尾（挥手 Bye-bye）。
- 画面**全程动态**，禁止静止帧；每镜有连续动作 + 相机运动（推/移/摇/跟，幅度+速度）。

---

## 2. 英语句子规则（⛔ 幼儿专用）

### 2.1 难度锁定 Level1 / Level2
只使用以下两个级别的句子，或按此难度改写；**禁止**超过 5 个词的长句/复杂句式。

**Level1 超简单（3-4 词，零基础）**：
```
This is an apple. / I see an apple. / Look at the apple. / I like the apple.
It is an apple. / Hello, red apple. / Apple is red. / Big red apple.
Small green apple. / I love apples. / Look, an apple. / Nice sweet apple.
One red apple. / Two green apples.
```

**Level2 简单扩展（4-5 词，初学）**：
```
This is a red apple. / This is a green apple. / I see one big apple.
I see two small apples. / Look at this sweet apple. / I like red apples best.
The apple looks nice. / The apple is round. / The apple is sweet.
Give me one apple. / Here is an apple. / Where is the apple?
Find the red apple. / Touch the apple gently.
```

（以上为 apple 示例库；其他单词按同难度改写，如 cat → This is a cat. / The cat is small.）

### 2.2 每段句数
- **每段至少 4-5 句**简单英语。
- 分布到各镜：开头 1 句、中间 2-3 句（含拼读 + 齐声跟读）、结尾 1-2 句。
- 拼读形式：`Apple! A-P-P-L-E. Apple!`（每个字母读出来）。
- 齐声跟读：off-screen children's chorus (S2) 回响 `<d>[English] Apple! Apple!</d>`。

### 2.3 语速
- 全程**慢语速**：提示词中固定写
  `All spoken English uses simple short words and is delivered at a slow, gentle pace with clear enunciation and a brief pause after each sentence, suitable for children to repeat.`
- 说话人描述用 `warm, gentle, slow-paced voice (S1)`。

---

## 3. 时间戳与分镜（10 秒 / 4 镜）

| 镜 | 切点 | 内容 |
|----|------|------|
| [Shot 1] | 开场 | 场景建立 + 钩子 + 第 1 句 |
| [Shot 2] | 00:02.500 | 核心动作 + 第 2-3 句（含拼读/齐声） |
| [Shot 3] | 00:05.000 | 推进剧情 + 第 4 句 |
| [Shot 4] | 00:07.500 | 悬念/收尾 + 第 5 句 |

- 切镜用 `the camera cuts to` / `the shot transitions to`。
- 相机运动用 Motion type + Amplitude + Speed 自然句（Push In / Truck / Tilt / Tracking 等）。

---

## 4. 输出模板（六段式全参考 · 单段示例骨架）

```text
subject_definitions:
<Subject 1> is the cute chibi child in the uploaded reference image ref_image_1, with a round soft face, warm light brown irises, tiny gentle pupils, soft rounded cartoon eyes, simple stubby rounded three-finger hands, and a cozy outfit; this subject is used only to define the child's appearance, which must stay identical in every shot.

summary:
[reference generation] The target video is exactly 10.00 seconds long, vertical 9:16, a children's English-learning clip in a warm storybook style with continuous motion throughout. <Subject 1>, the chibi child defined by the reference image, ... [单词剧情一句话] ... All English dialogue is made of very simple short sentences with basic words, spoken at a slow, gentle pace with clear enunciation and brief pauses, so young children can repeat each line easily. The reference image guides only the child's appearance; the [场景], [朋友], and all actions are newly generated.

retention_analysis:
<Subject 1> (appears in [Shot 1], [Shot 2], [Shot 3], [Shot 4]): fully_preserved - the child's round face, light brown irises, tiny pupils, soft cartoon eyes, three-finger stubby hands, outfit, and chibi proportions are retained in every shot.

detailed_description:
Vertical 9:16, 24fps, exactly 10.00 seconds. [画风句]. All spoken English uses simple short words and is delivered at a slow, gentle pace with clear enunciation and a brief pause after each sentence, suitable for children to repeat.
[Shot 1] ...（场景建立 + 钩子 + S1 第 1 句）
[Shot 2] At 00:02.500, ...（核心动作 + 拼读 + S2 齐声跟读）
[Shot 3] At 00:05.000, ...（推进 + 第 4 句）
[Shot 4] At 00:07.500, ...（悬念/收尾 + 第 5 句）
No text, letters, subtitles, or watermarks appear in any shot.

overall_soundscape:
[环境音 1-4 句，不重复对白]

non_diegetic_music:
[配器/速度/力度 1-3 句；各段间 BGM 同调性同配器，切点音量连续]
```

---

## 5. 交付格式

- 每次输出：**场景随机结果说明**（1 行）+ 完整可复制提示词（代码块）。
- 多段时：每段一个代码块，标注段号/场景/方案（A/B）。
- 附 1-3 行操作提示（传 ref_image_1 角色参考、时长 10 秒、9:16、方案 B 拼接/方案 A 延长）。
- 用户可要求：换场景、换朋友、加/减句子、调语速、改画风、改时长、生成句式清单。

---

## 6. 与 seedance 的关系

- 本 skill 是 seedance（通用视频提示词）的幼儿英语专用分支：H3 格式规范同源（references/ 已复制），
  但锁定幼儿专属规则（角色/句子难度/语速/时长/分段/钩子）。
- seedance 保持通用（短剧、广告等任意主题），互不影响。
