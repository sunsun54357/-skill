# 分镜提示词格式参考（H3 标准 · 四件套适配）

本文件是 novel-storyboard 写提示词时的**唯一格式依据**：灯光、摄像角度、镜头语言、H3 输出结构全部汇总在这里。写分镜前先读本文件。

## 1. 四件套对接约定

### 1.1 画风继承（先于一切）

开场风格句必须与角色/美术同档（`realistic` 半写实厚涂 / `ghibli` 吉卜力）。realistic 档标准句：

```text
Semi-realistic cinematic short-drama style, painterly rendering with soft blended edges and visible brush texture, anatomically grounded characters in weathered, lived-in environments, cinematic depth.
```

一部剧内禁止混用两种渲染档。

### 1.2 参考标签 ↔ 四件套原料

| 标签 | 含义 | 原料 |
| --- | --- | --- |
| `<Subject N>` | 可复用可见内容单元 | 角色 ← cast.json `image.prompt`；场景 ← art.json 场景 `image.prompt`+锚点；道具 ← art.json 道具 `image.prompt` |
| `<Picture N>` | 具体首帧/关键帧/尾帧/构图锚 | 设定图 `images/<slug>-sheet.png`、上一镜尾帧 |
| `<Video N>` | 剪辑源/续接起点/整片时间结构 | 上一镜、上一集结尾 |
| `<Audio N>` | 复制或参考的音频 | TTS 台词参考、BGM 风格 |

只用于定义角色/场景/服装/风格的图像不立 `<Picture N>`，写进对应 `<Subject N>` 定义（注明来源）。

### 1.3 台词与说话人

- 台词逐字取自 script.json `flow[].line`，语言标签 `<d>[Chinese] …</d>`，逐字保留，只规范标点（`,` `.` `?` `!`），去重复波浪号/emoji/装饰符号；完整句以 `.` `?` `!` 收尾。
- `(Sx)` 按**全片实际发声顺序**编号；先按台词本规划、再写 `subject_definitions`（定义段先于描述段书写）。不发声角色不占号。
- 心声/画外音：`says in an off-screen voiceover`，紧跟的 `<d>` 后写 `while his/her lips remain completely closed`；一集 VO ≤ 3 条。
- 台词跨切点：`<scenetrans>` + `continues seamlessly across the cut` 等；被视频结尾截断：`<cutoff>`。

### 1.4 时长折算

| 来源 | 折算 |
| --- | --- |
| 台词节拍 | 非空白字数（含标点）÷ 4.5 秒 |
| 动作节拍 | 2.5 秒/拍 |
| 每集目标 | script.json `targetSeconds × (1 ± 15%)` |
| 每集镜头数 | 60 秒集 8–15 镜，每镜 1.5–10 秒 |
| 镜头切点 | 从节拍流逐拍累加，落在拍边界 |

### 1.5 光照状态

- 每镜 `lighting` 只能取 art.json 该场景**已登记**的状态（如 `S01`：`傍晚暖光` / `深夜冷白`）。
- 需要新状态：先回 art.json 补登记，再回来写镜头，**不要绕过质量门**。
- 提示词里光照要写具体（光源方向/色温/强度/投影），不用「暖色调」这种抽象词。

## 2. H3 输出结构

### 2.1 对齐句（图像模式必用，且为提示词最首行，后跟空行）

```text
I2VA:  For the target video, at 0.00 seconds into the target video, <Picture 1> (from [Shot 1]) is fully referenced.
FL2VA: How the reference pictures align with the target video — <Picture 1> (from [Shot 1]) aligns with the 0.00-second mark of the target video; <Picture 2> (from [Shot N]) aligns with the S.SS-second mark of the target video.
L2VA:  How the reference pictures align with the target video — <Picture 1> (from [Shot N]) aligns with the S.SS-second mark of the target video.
```

- `N` = 实际末镜编号；`S.SS` = 视频有效时长，精确两位小数（`8.00`）。
- I2VA 的 `<Picture 1>` 是 0.00 秒真实首帧；L2VA 的 `<Picture 1>` 是末镜最后一帧。
- T2VA 无图像锚，无对齐句，直接以三核心字段开头。

### 2.2 三核心字段（T2VA / I2VA / FL2VA / L2VA 共用）

```text
integrated_multimodal_description: [Shot 1] ...

overall_soundscape: ...

non_diegetic_music: ...
```

- 正文英文；对白 `<d>[Chinese]`；画面可见文字用英文双引号逐字保留（`A sign reading "营业中" ...`）。
- `overall_soundscape`：1–4 句英文总结全片环境音/物理音/非语言人声；镜头同步的声音留在正文。
- `non_diegetic_music`：1–3 句英文写配器/速度/力度变化，不用情绪词；无则 `N/A`。

### 2.3 时间格式

| 语境 | 格式 | 示例 |
| --- | --- | --- |
| 镜头切点（后续镜头开头） | `MM:SS.mmm` | `[Shot 2] At 00:03.000, ...` |
| 对齐句锚点时刻 | `S.SS` | `aligns with the 8.00-second mark` |

首镜 `[Shot 1]` 不带时间戳。切点时间严格递增且落在时长内；只改距离/微角度用运镜不切镜。

### 2.4 说话人与对白格式

- 发声者 `(S1)`、`(S2)`…，多人同声 `(S1,S2)`；首次出现给身份（角色类型/年龄/性别/是否出镜/音色/语速/口音）。
- 对白：`<Subject N> (Sx) turns and says, <d>[Chinese] ...</d>`；画外：`<Subject N> (Sx), off-screen`。

### 2.5 字数基准

- 生成任务 `integrated_multimodal_description` 350–500 英文词（对话密集以台词时间线优先，不机械凑数）；分镜批次单每镜 60–170 词。
- **FL2VA / L2VA 例外**：因须同时写清首帧与尾帧（或收敛帧）两套四要素状态，可到 200–210 词——内容密度优先，不砍信息凑上限。
- 视频编辑/续接类随源复杂度伸缩。

## 3. 模式选用

| 模式 | 用途 | 短剧典型场景 |
| --- | --- | --- |
| **T2VA** | 纯文字生成 | 对话续接、过场 |
| **I2VA** | 首帧锚定向前发展 | 场景建立、新角色登场（设定图做首帧） |
| **FL2VA** | 首尾两帧之间插值 | **动作状态转变**：短棍凭空消失、被打被抢、端水稳住 |
| **L2VA** | 末帧锚定前推收敛 | 末镜落幅（空巷、屋内） |

判定：没有明确的状态转变动作就别用 FL2VA；没有可用的图像锚就老实 T2VA。

## 4. 镜头语言全表（景别 / 运镜 / 角度 / 节奏 / 焦点）

英文表达 = **Motion type + Amplitude + Speed**（幅度中等、速度常规时省略）：

| 维度 | 词汇 |
| --- | --- |
| 景别 | 大远景 extreme long shot / 远景 long shot / 全景 full shot / 中景 medium shot / 近景 close shot / 特写 close-up / 大特写 extreme close-up |
| 运镜-推拉 | Zoom In/Out（变焦不动机位）/ Push In/Pull Out（机位前移后移） |
| 运镜-摇移 | Pan Left/Right（机位不动镜头水平转）/ Truck Left/Right（机位水平平移）/ Tilt Up/Down（镜头垂直转）/ Pedestal Up/Down（整机升降） |
| 运镜-跟环 | Tracking Shot（跟拍移动主体）/ Arc Shot（环绕）/ 航拍 aerial shot |
| 运镜-其他 | Static Shot（固定）/ Shake Slightly/Strongly（轻微/强烈晃动）/ POV（主观视角）/ Roll Clockwise/Counterclockwise（镜头滚转） |
| 角度 | 平视 eye-level / 俯拍 high angle / 仰拍 low angle / 鸟瞰 bird's-eye / 鱼眼 fisheye |
| 节奏 | 慢动作 slow motion / 快切 fast cuts / 硬切 hard cut / 一镜到底 one-take / 升格 high frame rate / 卡点 beat-sync |
| 焦点 | 浅景深 shallow depth of field / 深景深 deep focus / 焦点转移 rack focus / 虚化背景 bokeh / 选择性对焦 selective focus |
| 幅度速度 | `with small amplitude` / `with large amplitude`；`at slow speed` / `at fast speed` |

写法：自然英文动作句，不堆标签。例：

```text
The camera pushes in with small amplitude at slow speed toward the folded letter in her hands.
The camera pans right with large amplitude at fast speed, revealing the open doorway.
```

## 5. 灯光设计要点

- 光源方向：key light（主光）/ fill light（补光）/ rim light（轮廓光）/ backlight（背光）；写清来自左上/右侧等方位。
- 色温质感：warm tungsten / cool fluorescent / cold moonlight / golden hour / dim yellowish bulb。
- 体积与氛围：volumetric light / haze / light shaft / pool of light / ambient occlusion / cast shadow。
- 环境真实感：weathered, lived-in materials（掉漆、水渍、包浆、磨白木纹）——这是环境的「真实感」来源，皮肤那套毛孔/皮下散射是角色 skill 的事，**不要带进场景提示词**。
- 全片灯光随光照状态走：换时段 = 换提示词重新生成，不是现场重新打灯。

## 6. @引用 ↔ H3 标签映射（即梦/平台上传）

| 即梦素材 | H3 标签 | 判定 |
| --- | --- | --- |
| `@图片N` | `<Picture N>` | 该图作为某镜首帧/尾帧/关键帧/构图锚 |
| `@图片N` | `<Subject N>` | 只用于定义角色/场景/服装/风格 |
| `@视频N` | `<Video N>` | 剪辑源/续接起点/整片时间结构 |
| `@视频N` | `<Subject N>` | 视频中可复用的可见内容 |
| `@音频N` | `<Audio N>` | 音色参考/对白复用/BGM/音效 |

编号：`<Picture N>` / `<Video N>` / `<Audio N>` 各自独立编号；同一素材可同时是 `<Video 1>` 与 `<Audio 2>`。绑定说话人的 `<Audio N>` 直接写 `<Subject N> (Sx)`。**写清楚是「参考」还是「编辑」**——参考是借鉴风格/动作，编辑是在原素材上修改。

## 7. 全参考模式六段式（有参考素材需标注来源与保留关系时）

```text
subject_definitions:    每个参考标签一行（含义 + 参考角色 + 主要特征 + 来源）
summary:                [task type] 一段英文概述（keyframe completion / reference generation / video editing / video continuation / audio reuse / audio reference，用 + 组合不重复）
retention_analysis:     每标签一行：visible 用 fully_preserved / partially_preserved / attribute_transfer / weak_reference；audio 用 fully_copy / partially_copy / reference / weak_reference；不写 (Sx)
detailed_description:   按播放顺序逐镜；参考标签在首次出现处与作用处插入；风格句在 [Shot 1] 之前
overall_soundscape:     环境音/物理音总结；复制类参考在此声明
non_diegetic_music:     观众专属 BGM；直接复用的配乐在此声明
```

音频参考：直接复用原对白/歌词时 `<d>` 内逐字保留；仅参考音色/节奏时**不**把原台词带进目标视频。只存在于直接复用的 BGM/完整音轨里的声音用 `<Audio N>` 作声源，不发明 `(Sx)`。

## 8. 网页版约定（render 生成）

每镜卡片三要素 + 一键复制：

| 要素 | 内容 |
| --- | --- |
| **几秒** | 时长（高亮）+ 起止时间 |
| **照片** | **`ref_image_1 ~ ref_image_8`** 槽位：锚点（首帧/末帧/起帧）优先，再按 refs 排角色/场景/道具参考图，来源去重、上限 8；每槽位给用途 + 图片生成提示词（art/cast.json 内嵌，可复制去千问/即梦出图）。无形象卡的角色/陈设只进出现清单，不给槽位 |
| **内容** | 完整 H3 提示词，**图片引用一律 `ref_image_N`**（render 时由 `<Picture N>` / `<Subject N>` 自动改写；无槽位的主体标签直接移除） |

复制：每镜「复制提示词」主按钮 + 图片提示词 + 负面词；每集「复制本集全部」；页头「复制全集」。T2VA 镜标「纯文本生成 · 无需图片」。页头注明：短剧建议竖屏 9:16；平台单次 4–15s，短于 4s 的镜生成 4s 后剪辑；一镜最多 8 张参考图。

### 8.1 ref_image_N 槽位分配规则（确定性，脚本执行）

1. **锚点优先**：I2VA 首帧 = `ref_image_1`；FL2VA 起帧 = `ref_image_1`、末帧 = `ref_image_2`；L2VA 末帧 = `ref_image_1`
2. **refs 主体随后**：按 refs 顺序分配角色/场景/道具参考图；与锚点同一来源（如主场景既是首帧又是 refs 主体）**去重**，共用一个槽位
3. **只给有图可出的主体**：cast.json 有形象卡的角色、art.json 的场景/道具才占槽位；无卡角色（功能性角色）不占槽位，提示词里移除其标签、保留文字描述
4. **续接参考图（排最后）**：除每集首镜和 FL2VA 外，每个非首镜的**最末槽位**追加 `ref_image_N` =「上一镜尾帧 = 本镜首帧」——取上一镜成图末帧上传（无需单独生成）；提示词最前面按 H3 格式声明它是首帧：`For the target video, at 0.00 seconds into the target video, ref_image_N (from [Shot 1]) is fully referenced — this image is the last frame of the previous shot and is the exact first frame of this video. The video opens on this frame and continues the previous shot's action seamlessly.`；I2VA 镜的原设定图首帧声明让位为「design reference image」，避免一镜双首帧；FL2VA 的 ref_image_1 本就是「起帧（上一镜尾帧续接）」，不重复追加
5. **尾帧自动提取**：视频按镜号命名（`<镜号>.mp4`）放入目录，运行 `node scripts/novel-storyboard.mjs extract <视频目录> --out images`，每支视频最后一帧存为 `images/<镜号>-tail.png`（依赖 Python + opencv；中文路径自动暂存 ASCII 临时路径处理；已存在跳过、幂等）；网页版续接槽位检测到该文件后自动显示预览图；FL2VA 起帧槽位同样挂上一镜尾帧图
6. 上限 8 个；超出部分以文字描述为准

示例（FL2VA 怪人镜）：`ref_image_1` 起帧（上一镜尾帧续接）→ `ref_image_2` 末帧（场景主视角）→ `ref_image_3` 僻静小巷 → `ref_image_4` 神秘怪人 → `ref_image_5` 银灰短棍；提示词里 `<Picture 1/2>`、`<Subject N>` 全部改写为对应 `ref_image_N`。

示例（T2VA 续接镜）：`ref_image_1` 便利店 → `ref_image_2` 林砚 → `ref_image_3` 苏晚 → `ref_image_4` 上一镜尾帧 = 本镜首帧；提示词以 ref_image_4 的首帧声明开头，正文继续引用 ref_image_1/2/3。

## 9. 提示词写作硬规则：首帧锚定 + 站位/姿势/动作/摄像机位

模型是**拿着首帧图开始生成**的。正文开头如果写的是与首帧无关的场面，首帧图就白给了——生成结果必然丢首帧。规则如下（写每一镜提示词必须遵守）：

### 9.1 正文第一句 = 首帧可见状态（四要素，一个都不能少）

`[Shot 1]` 第一句先**定格首帧**，写清四件事，再写动作：

| 要素 | 写什么 | 示例 |
| --- | --- | --- |
| 摄像机位 | 机位 / 角度 / 景别 / 构图 | A medium-wide shot from inside the store, counter on the left of frame |
| 站位 | 谁在画面什么位置、距离多远 | the boy in the navy uniform behind the worn wooden counter, left of frame; the girl at the glass door, right of frame |
| 姿势 | 当前姿态 | his hand paused on the counter edge, body half-turned toward the door; her hand still on the door handle |
| 场景状态 | 环境与光照现状 | warm fluorescent light on, the door ajar, dusk outside |

然后动作从该状态延续：`From this exact state, ...`——动作序列不许跳场、不许与首帧矛盾。

### 9.2 首帧图引用写法

- **I2VA**（设定图首帧）：`The shot begins from <Picture 1>, ...` 后紧跟 9.1 四要素描述。
- **续接首帧**（上一镜尾帧，T2VA/I2VA/L2VA 都有）：正文开头写 `The video opens on the exact first frame shown in ref_image_N: [四要素描述]. From this state, ...`——首帧里有什么就写什么（哪怕上一镜尾帧拍的是角色背影/空巷，就写背影/空巷），动作从那里延续。

### 9.3 尾帧锚定（FL2VA / L2VA）

- **FL2VA**：写清末帧状态：`The shot ends on the exact frame shown in ref_image_M: [末帧四要素]`，中间是首帧→末帧的连续变化（位移/姿势/镜头）。
- **L2VA**：正文明确收敛：`The scene settles into the exact frame shown in ref_image_1: [末帧四要素]`。

### 9.4 禁止

- 正文开头出现与首帧矛盾的场面（首帧室内，第一句却写室外）。
- 开头先铺一段"气氛/背景"再接首帧——**首帧就是第一句**。
- 站位/姿势/动作/机位含糊（"a man walks" 没有位置、机位、姿态）。
- 动作节拍写成散文（`气氛很尴尬` 不是画面）；每一拍是可见动作。

> ⛔ 本规则是**代码级校验门**：`validate` 会去掉对齐句后检查正文开头 200 字符是否含首帧锚定句（`opens on the / begins from / exact first frame / settles into` 等），不通过直接报「提示词正文未从首帧写起」。网页版每镜带「首帧锚定 ✓/✗」徽章，✗ 的镜头重新写。

### 9.5 完整示例（T2VA 续接镜改写前后）

改写前（首帧无锚定）：

```text
integrated_multimodal_description: [Shot 1] Semi-realistic cinematic short-drama style. Continuing in the convenience store, the girl steps closer and says, <d>[Chinese] 有两个人，跟了我一路。</d>
```

改写后（首帧锚定 + 四要素 + 动作从首帧延续）：

```text
integrated_multimodal_description: [Shot 1] Semi-realistic cinematic short-drama style. The video opens on the exact first frame shown in ref_image_4: a medium-wide shot from just inside the store entrance, the boy in the faded navy school uniform standing behind the worn wooden counter on the left, his hand paused on the counter edge, body half-turned toward the door; the girl in the light cardigan at the glass door on the right, her hand still on the handle, the door ajar, warm fluorescent light spilling onto the sidewalk, dusk outside. From this exact state, the girl steps fully inside, lets the door close with a soft thud, walks to the counter and stops a pace away, breathless; she presses her hands flat on the counter, knuckles white, and says, <d>[Chinese] 有两个人，跟了我一路。</d> The camera holds a static shot as the boy's hand pauses on the counter.
```
