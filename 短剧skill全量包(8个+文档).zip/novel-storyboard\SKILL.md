---
name: 短剧分镜
version: 1.0.0
description: |
  给 AI 短剧出分镜层交付物：镜号、单镜头时长、模式（T2VA / I2VA / FL2VA / L2VA）、
  H3 格式视频提示词、首帧来源、生成批次单，以及一键复制网页版（H3分镜提示词.html）。
  上游是 novel-script（剧本），配合 novel-outline / novel-art / novel-characters 四件套 JSON；
  产出 <剧名>-分镜.json + <剧名>-分镜表.md + <剧名>-H3分镜提示词.html。
  13 道质量门由脚本确定性检查（镜头数 8-15、总时长 60±15%、起止链连续、单镜 ≥1.5s、
  光照已登记、台词逐字覆盖、说话人映射合法、模式与动作匹配、首帧锚定等），不靠模型自觉；
  零依赖零 API key，node 直接跑。
  Use when asked to 分镜、分镜表、H3分镜提示词、镜号、镜头提示词、storyboard、分镜网页版、批量生成视频提示词。
---

# 短剧分镜

给 AI 短剧出**分镜层交付物**：镜号、单镜头时长、模式（T2VA / I2VA / FL2VA / L2VA）、H3 格式视频提示词、首帧来源、生成批次单，以及**一键复制网页版**。

**位置**：novel-script 的下一层。剧本管戏，分镜管拍——本 skill 只有镜号、时长、提示词、批次单，不写剧情、不做角色/场景设定、不出图。

`{baseDir}` = 本文件所在目录。脚本 `{baseDir}/scripts/novel-storyboard.mjs`，零依赖，`node` 直接跑。

**交付物三件套（⛔ 网页版必出）**：

```
<输出目录>/
├── <剧名>-分镜.json             机器可读批次单（58 镜示例见 examples/）
├── <剧名>-分镜表.md             可读分镜表 + 每镜完整提示词
└── <剧名>-H3分镜提示词.html     ⛔ 一键复制网页版：集导航 + 每镜「几秒/图片/内容」+ 复制按钮
```

---

### Step 0 — 输入检查

四件套 JSON 缺一不可：

| 文件 | 用途 |
| --- | --- |
| `<剧名>-script.json` | **直接上游**：节拍流、台词、单集目标秒数 |
| `<剧名>-outline.json` | 角色 C 编号 → 名字（cast.json 没有 id 字段） |
| `<剧名>-art.json` | 场景 id/名称/**光照状态**/场景图片提示词 |
| `<剧名>-cast.json` | 角色名 → 形象提示词（图片生成提示词来源） |

缺哪个先跑对应 skill；从小说全流程按 characters → outline → art → script → 本 skill 顺序。输出目录默认原剧目录。

### Step 1 — seed 骨架（脚本确定性搬运 ⛔）

```bash
node {baseDir}/scripts/novel-storyboard.mjs seed <script.json> \
  --art <art.json> --outline <outline.json> --eps 1-3 > <workdir>/seed.json
```

确定性算好，**不要模型重算**：逐拍时长（台词 = 非空白字数 ÷ 4.5，动作 = 2.5 秒/拍）、每场登记场景与光照、按全片发声顺序排 `(Sx)` 映射。

### Step 2 — 逐集分镜（模型工作）

每集一份（支持子代理并发，同一条消息全部发出）。每份任务拿到：seed 骨架、该集节拍流、`references/format.md`（**灯光/摄像角度/镜头语言/H3 格式全表**，读它照着写）。

产出 `<workdir>/ep<N>.json`，每条 `shot`：

| 字段 | 规则 |
| --- | --- |
| `shotId` | `E<集>S<场>-<序号>` |
| `mode` | 场景/新角色登场用 I2VA；对话续接用 T2VA；**动作状态转变**（打斗/消散/端水稳住）用 FL2VA；末镜落幅用 L2VA |
| `sceneId` / `lighting` | 只允许 art.json 已登记的光照状态 |
| `startSeconds/endSeconds/durationSeconds` | 由拍时长累加，60 秒集总时长落在 [51,69] |
| `firstFrameSource` | 图像模式写明首帧/末帧来源（`images/<slug>-sheet.png`，注明 art/cast 来源与待出图） |
| `refs` | `<Subject N> 名称（来源 json）` |
| `prompt` | H3 格式：对齐句（图像模式）+ `integrated_multimodal_description: [Shot 1] ...` + `overall_soundscape: ...` + `non_diegetic_music: ...`。**图片引用用 `<Picture N>` / `<Subject N>` 书写，render 时自动改写为 `ref_image_N`**（MiniMax H3 上传参考图命名）；无形象卡的角色（如功能性角色）不给槽位，只文字描述。**正文必须从首帧可见状态写起**（摄像机位/站位/姿势/场景状态四要素，见 `references/format.md` §9），动作从首帧延续；FL2VA/L2VA 还要写明末帧锚定状态 |
| `negativePrompt` | 默认禁多余人物/塑料 CG/透视扭曲/畸形手/文字水印；故意有人群的镜换人群版 |
| `dialogue` | 台词逐字来自 script.json，`<d>[Chinese] ...</d>` |

每集 8–15 镜，每镜 1.5–10 秒，切点落在拍边界。写完删掉 seed 里的提示残留。

### Step 3 — 校验 ⛔ 不能跳

```bash
node {baseDir}/scripts/novel-storyboard.mjs validate <workdir>/ep<N>.json \
  --script <script.json> --art <art.json> --outline <outline.json>
```

质量门全是代码：镜头数 8–15、总时长 60±15%、起止链连续、单镜 ≥1.5s、光照已登记、场景/角色存在、台词逐字覆盖（剧本每句台词都出现在批次单里）、说话人映射合法、模式与动作匹配（没有状态转变的动作别硬凑 FL2VA）、提示词含 `[Shot 1]`、图像模式含对齐句、T2VA 无对齐句、**提示词正文从首帧写起**（首帧锚定：去掉对齐句后开头 200 字符须含 `opens on / begins from / exact first frame / settles into` 等，见 `references/format.md` §9）。有违规逐条修，改完重跑，直到通过。

### Step 4 — 合并 + 渲染 ⛔ 网页版必出

```bash
node {baseDir}/scripts/novel-storyboard.mjs merge <workdir> \
  --out <输出目录>/<剧名>-分镜.json
node {baseDir}/scripts/novel-storyboard.mjs render <剧名>-分镜.json \
  --art <art.json> --cast <cast.json> --outline <outline.json> --script <script.json> --out <输出目录>
```

- `merge`：按集合并、跨集校验、落盘 `分镜.json`
- `render`：生成 `分镜表.md` + **`H3分镜提示词.html`**（⛔ 必须交付，用户要的就是这个）
- 网页版自动：集导航、每镜卡片三要素（**几秒**=时长+起止 / **照片**=`ref_image_1~8` 槽位+用途+图片生成提示词 / **内容**=完整 H3 提示词，图片引用已改写为 `ref_image_N`）、**续接参考图**（非首镜最末槽位 = 上一镜尾帧 = 本镜首帧，提示词按 H3 格式声明 `is fully referenced ... exact first frame`）、出现清单（场景/人物/道具/陈设）、每镜/每集/全集一键复制、负面词折叠

**提取尾帧（视频生成后，续接图自动回填）**：

```bash
# 生成的视频按镜号命名下载到 videos/ 目录（如 E1S01-02.mp4），然后：
node {baseDir}/scripts/novel-storyboard.mjs extract videos/ --out <输出目录>/images
```

- 每支视频最后一帧 → `images/<镜号>-tail.png`；网页版续接槽位检测到该文件后自动显示预览图（`<img class="tail-preview">`）
- FL2VA 的起帧槽位同样挂上一镜的尾帧图
- 依赖 Python + opencv（`cv2`）；脚本已处理中文路径（自动暂存 ASCII 临时路径读写）；已存在的输出自动跳过（幂等）

### Step 5 — 汇报

一句话说清：几集几镜、全剧预估时长 vs 目标、模式分布、`H3分镜提示词.html` 路径；没过的门和没出的图明说。

---

## 与上游 skill 的接力

```
novel-characters → cast.json    （谁：角色资产）
novel-outline    → outline.json （什么：结构与分集）
novel-art        → art.json     （哪里 + 手里拿的：场景/光照/道具）
novel-script     → script.json  （戏：场次、节拍、台词）
novel-storyboard → 分镜.json + 分镜表.md + H3分镜提示词.html（拍：镜号/时长/提示词/批次单）
```

## 边界

- 不改剧本/大纲结构；不做角色/场景设定
- 提示词正文英文（H3 标准），对白 `<d>[Chinese]` 保留原文
- 时长是估算不是秒表，±15% 容差；平台单次生成 4–15 秒，短于 4 秒的镜生成 4 秒后剪辑
- 短剧建议竖屏 9:16（网页版页头注明）
- 图片生成提示词内嵌自 art/cast.json；设定图仍走 codex `$imagegen` 出图（可选）

## 自测

```bash
node {baseDir}/scripts/selftest.mjs
```

不调模型、不花额度，覆盖：时长折算、说话人映射、validate 击穿用例、render 网页版关键结构。

## 自带样例

`{baseDir}/examples/起点-分镜.json`：5 集 58 镜完整批次单（I2VA×12 / T2VA×36 / FL2VA×5 / L2VA×5，全剧 301.4s/300s），当质量基准与测试夹具。
